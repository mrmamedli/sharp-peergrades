﻿using System;
using System.IO;

namespace Matrix_Calculator
{
    /// <summary>
    /// Класс, реализующий консольное приложение "Калькулятор матриц".
    /// </summary>
    class Program
    {
        /// <summary>
        /// Точка входа. Справка о работе калькулятора для пользователя.
        /// </summary>
        static void Main()
        {
            while (true)
            {
                Console.Clear();
                Console.Write("Вас приветствует \"Калькулятор матриц\"!\nВыберите действие, которое хотите выполнить:\n" +
                              "1 -> найти след матрицы;\n2 -> транспонировать матрицу;\n3 -> найти сумму двух матриц;\n" +
                              "4 -> найти разность двух матриц;\n5 -> найти произведение двух матриц;\n" +
                              "6 -> умножить матрицу на число;\n7 -> найти определитель матрицы;\n" +
                              "8 -> решить СЛАУ методом Крамера.\n9 -> выйти из программы.\n\n" +
                              "Программа работает с матрицами размером от 1х1 до 10х10 вещественных чисел, по" +
                              " модулю не превосходящих 100.\nРазмеры матрицы задаются клавишами 0-9 (0 считается за 10)" +
                              "\nВ ходе работы вещественные числа округляются до двух знаков после запятой,\nтак что " +
                              "возможны неточные вычисления (так, 99,999 = 100)\nПожалуйста, введите номер команды, " +
                              "которую вы хотите выполнить.\nНекорректный ввод игнорируется. Помните про региональные " +
                              "настройки ввода вещ. чисел!\n");
                Choice();
            }
        }

        /// <summary>
        /// Выбор команды для текущего запуска программы.
        /// </summary>
        static void Choice()
        {
            // Обработка различных нажатых клавиш.
            ConsoleKeyInfo key;
            while (true)
            {
                key = Console.ReadKey(true);
                switch (key.KeyChar)
                {
                    case '1':
                        Trace();
                        return;
                    case '2':
                        Transpose();
                        return;
                    case '3':
                        Sum();
                        return;
                    case '4':
                        Substract();
                        return;
                    case '5':
                        MultiplyMatrix();
                        return;
                    case '6':
                        MultiplyNumber();
                        return;
                    case '7':
                        FindDeterminator();
                        return;
                    case '8':
                        SolveLinearSystem();
                        return;
                    case '9':
                        Environment.Exit(0);
                        return;
                }
            }
        }

        /// <summary>
        /// Выбор способа генерации матрицы.
        /// </summary>
        static double[,] GetMatrix(int rows, int columns)
        {
            Console.Write($"\nВыберите способ создания матрицы {rows}x{columns}:\n" +
                          "1 -> генерация числа компьютером;\n2 -> ввод через консоль;\n3 -> ввод через файл;\n" +
                          "Пожалуйста, введите номер способа, который вы хотите выбрать." +
                          " Некорректный ввод игнорируется.\n\n");
            ConsoleKeyInfo key;
            while (true)
            {
                key = Console.ReadKey(true);
                switch (key.KeyChar)
                {
                    case '1':
                        return CreateRandomMatrix(rows, columns);
                    case '2':
                        return CreateConsoleMatrix(rows, columns);
                    case '3':
                        return CreateFileMatrix(rows, columns);
                }
            }
        }

        /// <summary>
        /// Генерация матрицы компьютером.
        /// </summary>
        /// <returns>Матрица, сгенерированная программой.</returns>
        static double[,] CreateRandomMatrix(int rows, int columns)
        {
            // С помощью класса Random для каждого элемента матрицы генерируется вещественное значение. 
            var rand = new Random();
            var matrix = new double[rows, columns];
            for (var row = 0; row < rows; row++)
            {
                for (var column = 0; column < columns; column++)
                {
                    matrix[row, column] = Math.Round((rand.NextDouble() + rand.Next(-100, 99)), 2);
                }
            }
            Show(matrix);
            return matrix;
        }

        /// <summary>
        /// Ввод матрицы пользователем через консоль.
        /// </summary>
        /// <returns>Матрица, введенная пользователем через консоль.</returns>
        static double[,] CreateConsoleMatrix(int rows, int columns)
        {
            // Создаем матрицу и заполняем ее в цикле.
            var matrix = new double[rows, columns];
            string usersInput;
            Console.Write($"Вам предстоит заполнить матрицу {rows}х{columns}!\n");
            for (var row = 0; row < rows; row++)
            {
                Console.Write($"Заполняем строку {row + 1}.\n");
                for (var column = 0; column < columns; column++)
                {
                    while (true)
                    {
                        Console.Write($"Введите {column + 1} элемент строки: ");
                        usersInput = Console.ReadLine();
                        // Здесь и в остальных местах - проверка на число в нужном интервале.
                        if (!usersInput.Contains(' ') && double.TryParse(usersInput, out var number) && (number >= -100) && (number <= 100))
                        {
                            matrix[row, column] = Math.Round(number, 2);
                            break;
                        }
                        Console.Write("!!! -> Некорректный ввод, попробуйте еще раз.\n");
                    }
                }
            }
            Show(matrix);
            return matrix;
        }

        /// <summary>
        /// Ввод матрицы пользователем через файл matrix.txt.
        /// Пример корректной матрицы 5х6 уже лежит в файле.
        /// </summary>
        /// <returns>Матрица, введенная пользователем через файл.</returns>
        static double[,] CreateFileMatrix(int rows, int columns)
        {
            var matrix = new double[rows, columns];
            Console.Write(
                $"Пожалуйста, внесите матрицу {rows}х{columns} в файл matrix.txt (\\Matrix Calculator\\matrix.txt)!\n" +
                "Между соседними элементами одной строки должен стоять ОДИН пробел, каждая строка матрицы - с новой " +
                "строки файла, не должно быть лишних символов!\n");
            while (true)
            {
                Console.Write("Нажмите на любую клавишу, чтобы начать проверку файла!\n");
                Console.ReadKey(true);
                // Пытаемся открыть файл, в случае чего выбрасывается исключение и сообщение о некорректных данных.
                try
                {
                    // Открываем файл и считываем строки в массив.
                    using (StreamReader reader = new StreamReader("..\\..\\..\\matrix.txt"))
                    {
                        var listOfLines = reader.ReadToEnd().Split(Environment.NewLine);
                        // Проверяем количество строк с заданным.
                        if (listOfLines.Length != rows)
                            throw new Exception();
                        // Дробим строки, поэлементно переводим в дробные числа и кладем в массив.
                        string[] lineInList;
                        for (var row = 0; row < rows; row++)
                        {
                            // Проверяем, сколько элементов в строке.
                            lineInList = listOfLines[row].Split();
                            if (lineInList.Length != columns)
                                throw new Exception();
                            for (var column = 0; column < columns; column++)
                                matrix[row, column] = Math.Round(double.Parse(lineInList[column]), 2);
                        }
                        Show(matrix);
                        return matrix;
                    }
                }
                catch (Exception)
                {
                    Console.Write("!!! -> Некорректный ввод, попробуйте еще раз.\n");
                }
            }
        }

        /// <summary>
        /// Выводит след квадратной матрицы (след - сумма элементов квадратной матрицы на главной диагонали).
        /// </summary>
        static void Trace()
        {
            Console.Clear();
            Console.Write("-> СЛЕД МАТРИЦЫ\nПользователь вводит размерность квадратной матрицы, создает ее одним из " +
                "возможных способов,\nпосле чего программа находит след матрицы - сумму элементов главной диагонали.\n");
            var size = 0;
            GetSizeOfSquareMatrix(ref size);
            var matrix = GetMatrix(size, size);
            var answer = 0d;
            // Проходимся по диагонали.
            for (var row = 0; row < size; row++)
                answer += matrix[row, row];
            Console.Write($"След матрицы: {Math.Round(answer, 2)}\n");
            Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Получает размерность квадратной матрицы от пользователя.
        /// </summary>
        /// <param name="size">Размерность матрицы.</param>
        static void GetSizeOfSquareMatrix(ref int size)
        {
            ConsoleKeyInfo key;
            Console.Write("Пожалуйста, введите размерность матрицы, некорректный ввод игнорируется: ");
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out size))
                {
                    size = (size == 0) ? 10 : size;
                    break;
                }
            }
            Console.Write($"{size}\n");
        }

        /// <summary>
        /// Выводит транспонированную матрицу (то есть матрицу, в которой элементу [i, j] соответствует
        /// первоначальный [j, i]).
        /// </summary>
        static void Transpose()
        {
            Console.Clear();
            Console.Write("-> ТРАНСПОНИРОВАНИЕ МАТРИЦЫ\nПользователь вводит размеры матрицы, создает ее одним" +
                " из возможных способов,\nпосле чего программа выводит транспонированную матрицу.\n");
            var rows = 0;
            var columns = 0;
            GetSizeOfMatrix(ref rows, ref columns);
            var matrix = GetMatrix(rows, columns);
            Console.Write("Транспонированная матрица:\n");
            for (var column = 0; column < columns; column++)
            {
                Console.Write("   ");
                for (var row = 0; row < rows; row++)
                {
                    Console.Write("{0, -11}", matrix[row, column]);
                }
                Console.Write("\n");
            }
            Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Получает количество строк и столбцов в матрице от пользователя.
        /// </summary>
        /// <param name="rows">Количество строк.</param>
        /// <param name="columns">Количество столбцов.</param>
        static void GetSizeOfMatrix(ref int rows, ref int columns)
        {
            ConsoleKeyInfo key;
            Console.Write("Пожалуйста, введите количество строк в матрице, некорректный ввод игнорируется: ");
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out rows))
                {
                    rows = (rows == 0) ? 10 : rows;
                    break;
                }
            }
            Console.Write($"{rows}\nПожалуйста, введите количество столбцов в матрице, некорректный ввод игнорируется: ");
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out columns))
                {
                    columns = (columns == 0) ? 10 : columns;
                    break;
                }
            }
            Console.Write($"{columns}\n");
        }

        /// <summary>
        /// Выводит сумму двух матриц (поэлементное сложение).
        /// </summary>
        static void Sum()
        {
            Console.Clear();
            Console.Write("-> СУММА МАТРИЦ\nПользователь вводит размеры матриц, создает их возможными способами,\n" +
                "после чего программа выводит сумму полученных матриц.\n");
            var rows = 0;
            var columns = 0;
            GetSizeForSum(ref rows, ref columns);
            Console.Write("Первая матрица: ");
            var firstMatrix = GetMatrix(rows, columns);
            Console.Write("Вторая матрица: ");
            var secondMatrix = GetMatrix(rows, columns);
            Console.Write("Сумма матриц:\n");
            for (var row = 0; row < rows; row++)
            {
                Console.Write("   ");
                for (var column = 0; column < columns; column++)
                {
                    Console.Write("{0, -11}",
                        Math.Round(firstMatrix[row, column] + secondMatrix[row, column], 2));
                }
                Console.Write("\n");
            }
            Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Получает количество строк и столбцов в матрицах от пользователя.
        /// Метод для сложения и вычитания матриц.
        /// </summary>
        /// <param name="rows">Количество строк.</param>
        /// <param name="columns">Количество столбцов.</param>
        static void GetSizeForSum(ref int rows, ref int columns)
        {
            ConsoleKeyInfo key;
            Console.Write("Пожалуйста, введите количество строк в матрицах, некорректный ввод игнорируется: ");
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out rows))
                {
                    rows = (rows == 0) ? 10 : rows;
                    break;
                }
            }
            Console.Write($"{rows}\nПожалуйста, введите количество столбцов в матрицах, некорректный ввод игнорируется: ");
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out columns))
                {
                    columns = (columns == 0) ? 10 : columns;
                    break;
                }
            }
            Console.Write($"{columns}\n");
        }

        /// <summary>
        /// Выводит разность двух матриц (единственное отличие от Sum() - знак "-").
        /// </summary>
        static void Substract()
        {
            Console.Clear();
            Console.Write("-> РАЗНОСТЬ МАТРИЦ\nПользователь вводит размеры матриц, создает их возможными способами,\n" +
                "после чего программа выводит разность полученных матриц.\n");
            var rows = 0;
            var columns = 0;
            GetSizeForSum(ref rows, ref columns);
            Console.Write("Первая матрица: ");
            var firstMatrix = GetMatrix(rows, columns);
            Console.Write("Вторая матрица: ");
            var secondMatrix = GetMatrix(rows, columns);
            Console.Write("Разность матриц:\n");
            for (var row = 0; row < rows; row++)
            {
                Console.Write("   ");
                for (var column = 0; column < columns; column++)
                {
                    Console.Write("{0, -11}",
                        Math.Round(firstMatrix[row, column] - secondMatrix[row, column], 2));
                }
                Console.Write("\n");
            }
            Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Выводит матрицу, умноженную на число (поэлементное умножение).
        /// </summary>
        static void MultiplyNumber()
        {
            Console.Clear();
            Console.Write("-> ПРОИЗВЕДЕНИЕ МАТРИЦЫ И ЧИСЛА\nПользователь вводит размеры матрицы, создает ее одним из" +
                " возможных способов,\nвводит число, после чего программа выводит произведение этих матрицы и числа.\n");
            var rows = 0;
            var columns = 0;
            GetSizeOfMatrix(ref rows, ref columns);
            var matrix = GetMatrix(rows, columns);
            double number;
            string usersInput;
            Console.Write("Введите число, не превосходящее по модулю 100 (и помните про округление в программе!): ");
            while (true)
            {
                usersInput = Console.ReadLine();
                if (!usersInput.Contains(' ') && double.TryParse(usersInput, out number) && number >= -100.0 && number <= 100)
                    break;
                Console.Write("!!! -> Некорректный ввод, попробуйте еще раз: ");
            }
            number = Math.Round(number, 2);
            Console.Write($"Матрица, умноженная на {number}:\n");
            for (var row = 0; row < rows; row++)
            {
                Console.Write("   ");
                for (var column = 0; column < columns; column++)
                {
                    Console.Write("{0, -11}", Math.Round(matrix[row, column] * number, 2));
                }
                Console.Write("\n");
            }
            Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Выводит матрицу - произведение двух матриц (по определению - строка первой на столбец второй).
        /// </summary>
        static void MultiplyMatrix()
        {
            Console.Clear();
            Console.Write("-> ПРОИЗВЕДЕНИЕ МАТРИЦ\nПользователь вводит размеры матриц, создает их возможными способами,\n" +
                "после чего программа выводит произведение полученных матриц.\n");
            var rowsFirst = 0;
            var rowsSecond = 0;
            var columnsSecond = 0;
            GetSizeForMultiply(ref rowsFirst, ref rowsSecond, ref columnsSecond);
            Console.Write("Первая матрица: ");
            var firstMatrix = GetMatrix(rowsFirst, rowsSecond);
            Console.Write("Вторая матрица: ");
            var secondMatrix = GetMatrix(rowsSecond, columnsSecond);
            double element;
            Console.Write("Произведение матриц:\n");
            // Умножение по определению.
            for (var row = 0; row < rowsFirst; row++)
            {
                Console.Write("   ");
                for (var column = 0; column < columnsSecond; column++)
                {
                    element = 0;
                    for (var multiplyIndex = 0; multiplyIndex < rowsSecond; multiplyIndex++)
                    {
                        element += (firstMatrix[row, multiplyIndex] * secondMatrix[multiplyIndex, column]);
                    }
                    Console.Write("{0, -11}", Math.Round(element, 2));
                }
                Console.Write("\n");
            }
            Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Получает количество строк и столбцов в матрицах от пользователя.
        /// Метод для умножения матриц.
        /// </summary>
        /// <param name="rowsFirst">Количество строк в первой матрице</param>
        /// <param name="rowsSecond">Количество столбцов в первой матрице/строк во второй матрице.</param>
        /// <param name="columnsSecond">Количество столбцов во второй матрице.</param>
        static void GetSizeForMultiply(ref int rowsFirst, ref int rowsSecond, ref int columnsSecond)
        {
            ConsoleKeyInfo key;
            Console.Write("Пожалуйста, введите количество строк в первой матрице, некорректный ввод игнорируется: ");
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out rowsFirst))
                {
                    rowsFirst = (rowsFirst == 0) ? 10 : rowsFirst;
                    break;
                }
            }
            Console.Write($"{rowsFirst}\nПожалуйста, введите количество столбцов в первой матрице\n" +
                "(т.е. количество строк во второй матрице), некорректный ввод игнорируется: ");
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out rowsSecond))
                {
                    rowsSecond = (rowsSecond == 0) ? 10 : rowsSecond;
                    break;
                }
            }
            Console.Write($"{rowsSecond}\nПожалуйста, введите количество столбцов во второй матрице, " +
                $"некорректный ввод игнорируется: ");
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out columnsSecond))
                {
                    columnsSecond = (columnsSecond == 0) ? 10 : columnsSecond;
                    break;
                }
            }
            Console.Write($"{columnsSecond}\n");
        }

        /// <summary>
        /// Выводит определитель матрицы.
        /// </summary>
        static void FindDeterminator()
        {
            Console.Clear();
            Console.Write("-> ОПРЕДЕЛИТЕЛЬ МАТРИЦЫ\nПользователь вводит размерность квадратной матрицы, создает ее одним из " +
                "возможных способов,\nпосле чего программа находит определитель матрицы, приводя ее к ступенчатому виду.\n");
            var size = 0;
            GetSizeOfSquareMatrix(ref size);
            var matrix = GetMatrix(size, size);
            var determinator = 1d;
            FindGaussDeterminator(ref matrix, ref determinator);
            Console.Write($"Определитель матрицы: {Math.Round(determinator, 2)}\n");
            Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Приводит квадратную матрицу к ступенчатому виду и попутно считает определитель.
        /// </summary>
        /// <param name="matrix">Квадратная матрица.</param>
        /// <param name="determinator">Определитель.</param>
        /// <returns></returns>
        static void FindGaussDeterminator(ref double[,] matrix, ref double determinator)
        {
            // Проходимся по каждой строке.
            for (var row = 0; row < matrix.GetLength(0); row++)
            {
                // Проверяем, есть ли строка, в которой на главной диагонали стоит больший элемент.
                var changeRow = row;
                for (var otherRow = row + 1; otherRow < matrix.GetLength(0); otherRow++)
                    if (Math.Abs(matrix[changeRow, row]) < Math.Abs(matrix[otherRow, row]))
                        changeRow = otherRow;
                // Переставляем строки, если такая строка есть и умножаем определитель на -1 (из кососимметричности).
                double fromTo;
                if (row != changeRow)
                {
                    for (var column = row; column < matrix.GetLength(1); column++)
                    {
                        fromTo = matrix[row, column];
                        matrix[row, column] = matrix[changeRow, column];
                        matrix[changeRow, column] = fromTo;
                    }
                    determinator *= -1;
                }
                // Обнуляем все элементы в столбце под текущим, вычитая из строк ниже текущую с коэффициентом.
                if (matrix[row, row] != 0)
                    for (var otherLine = row + 1; otherLine < matrix.GetLength(0); otherLine++)
                        if (matrix[otherLine, row] != 0)
                        {
                            fromTo = matrix[otherLine, row] / matrix[row, row];
                            for (var column = row; column < matrix.GetLength(1); column++)
                                matrix[otherLine, column] -= (matrix[row, column] * fromTo);
                        }
            }
            // Считаем определитель как произведение диагональных элементов.
            for (var row = 0; row < matrix.GetLength(0); row++)
                determinator *= matrix[row, row];
        }

        /// <summary>
        /// Проверяет, есть ли у СЛАУ из N уравнений с N неизвестными единственное решение.
        /// </summary>
        static void SolveLinearSystem()
        {
            Console.Clear();
            Console.Write("-> РЕШЕНИЕ СЛАУ\nПользователь вводит размерность матрицы Nx(N + 1) (СЛАУ в матричном виде),\n" +
                "создает ее одним из возможных способов,\nпосле чего программа находит единственное решение СЛАУ методом Крамера " +
                "или сообщает о том,\nчто его невозмножно найти (либо решений нет, либо их бесконечное количество).\n");
            ConsoleKeyInfo key;
            Console.Write("Пожалуйста, введите количество переменных в матрице (клавиши 1-9), некорректный ввод игнорируется: ");
            int size;
            while (true)
            {
                key = Console.ReadKey(true);
                if (int.TryParse(key.KeyChar.ToString(), out size) && size != 0)
                {
                    break;
                }
            }
            Console.Write($"{size}\nВведите СЛАУ в матричном виде.\n");
            var matrix = GetMatrix(size, size + 1);
            // Матрица коэффициентов СЛАУ (кроме свободных).
            var matrixClone = new double[size, size];
            for (var row = 0; row < size; row++)
                for (var column = 0; column < size; column++)
                    matrixClone[row, column] = matrix[row, column];
            var determinator = 1d;
            FindGaussDeterminator(ref matrixClone, ref determinator);
            // По методу Крамера решение единственно, если определитель выбранной матрицы != 0.
            if (determinator == 0)
            {
                Console.Write("Данная СЛАУ не имеет единственного решения!\n");
                Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
                Console.ReadKey(true);
                return;
            }
            ShowLinearSystemAnswer(matrixClone, matrix, determinator);
            Console.Write("Нажмите на любую клавишу, чтобы продолжить...");
            Console.ReadKey(true);
        }

        /// <summary>
        /// Находит единственное решение СЛАУ методом Крамера.
        /// </summary>
        /// <param name="matrixClone">Квадратная матрица коэффициентов СЛАУ (кроме свободных).</param>
        /// <param name="matrix">Матрица СЛАУ.</param>
        /// <param name="determinator">Определитель квадратной матрицы коэффициентов СЛАУ.</param>
        static void ShowLinearSystemAnswer(double[,] matrixClone, double[,] matrix, double determinator)
        {
            Console.Write("Решения СЛАУ:\n");
            var determinatorVariable = 1d;
            // Для каждой переменной заменяем соответсвующий ей стобец на столбец свободных коэффициентов,
            // находим определитель и делим на определитель квадратной матрицы коэффициентов СЛАУ - это ее значение
            // в решении.
            for (var variable = 0; variable < matrixClone.GetLength(0); variable++)
            {
                for (var row = 0; row < matrixClone.GetLength(0); row++)
                    for (var column = 0; column < matrixClone.GetLength(1); column++)
                    {
                        if (column == variable)
                            matrixClone[row, column] = matrix[row, matrix.GetLength(1) - 1];
                        else
                            matrixClone[row, column] = matrix[row, column];
                    }
                determinatorVariable = 1d;
                FindGaussDeterminator(ref matrixClone, ref determinatorVariable);
                Console.Write($"\tx{variable + 1} = {Math.Round((determinatorVariable / determinator), 2)}\n");
            }
        }

        /// <summary>
        /// Отображение сгенерированной матрицы после создания.
        /// </summary>
        /// <param name="matrix">Сгенерированная матрица.</param>
        static void Show(double[,] matrix)
        {
            Console.Write($"Сгенерирована матрица {matrix.GetLength(0)}х{matrix.GetLength(1)}.\n");
            for (var row = 0; row < matrix.GetLength(0); row++)
            {
                Console.Write("   ");
                for (var column = 0; column < matrix.GetLength(1); column++)
                    Console.Write("{0, -11}", matrix[row, column]);
                Console.Write("\n");
            }
            Console.Write("\n");
        }
    }
}