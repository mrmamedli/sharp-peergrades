﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FileManager
{
    /// <summary>
    /// Основной класс программы, реализующий его работу.
    /// </summary>
    class Program
    {
        /// <summary>
        /// Основной метод приложения, отвечающий за его работу.
        /// </summary>
        private static void Main()
        {
            Console.Title = "File Manager";
            Console.Write($"[{Directory.GetCurrentDirectory()}]> ");
            ShowDescriptions();
            Console.WriteLine("-------------------------------------------");
            Console.Write("-> Нажмите ESC, чтобы продолжить...");
            ConsoleKeyInfo key;
            do
                key = Console.ReadKey(true);
            while (key.Key != ConsoleKey.Escape);
            Console.Clear();
            while (true)
            {
                try
                {
                    Console.Write($"[{Directory.GetCurrentDirectory()}]> ");
                    GetOperation();
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }

                Console.WriteLine("-------------------------------------------");
                Console.Write("-> Нажмите ESC, чтобы продолжить...");
                do
                    key = Console.ReadKey(true);
                while (key.Key != ConsoleKey.Escape);
                Console.Clear();
            }
        }

        /// <summary>
        /// Вывод информации о приложении.
        /// </summary>
        private static void ShowDescriptions()
        {
            Console.WriteLine("информация о приложении.");
            Console.WriteLine("Консольное приложение - \"Файловый менеджер\"");
            Console.WriteLine("!!! программа написана на VS, тестировалась только на Windows, так что может " +
                              "чуточку барахлить на других ОС.");
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine("Клавиши команд:");
            Console.WriteLine("F1 -> просмотр списка дисков;");
            Console.WriteLine("F2 -> просмотр файлов/поддиректорий в текущей директории;");
            Console.WriteLine("F3 -> переход в другую директорию (выбор диска здесь!);");
            Console.WriteLine("F4 -> вывод содержимого текстового файла (.txt) в некоторой кодировке (BOM - часть файла);");
            Console.WriteLine("F5 -> копирование файла в другую директорию (в ту же нельзя!!!);");
            Console.WriteLine("F6 -> перемещение файла;");
            Console.WriteLine("F7 -> удаление файла;");
            Console.WriteLine("F8 -> создание простого текстового файла (.txt);");
            Console.WriteLine("F9 -> конкатенация текстовых файлов (.txt);");
            Console.WriteLine("F10 -> поиск по маске (копирование выбранных файлов здесь!);");
            Console.WriteLine("ESC -> завершение приложения;");
            Console.WriteLine("любая другая клавиша -> вывод данного меню;");
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine("Клавиши кодировок:");
            Console.WriteLine("F1 -> ASCII;");
            Console.WriteLine("F2 -> Unicode;");
            Console.WriteLine("F3 -> UTF-32;");
            Console.WriteLine("любая другая клавиша -> UTF-8;");
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine("О вводе с помощью Tab:");
            Console.WriteLine("В подменю копирования, перемещения и удаления файла в патче от 08.11.2021\n" +
                              "введена экспериментальная функция ввода названия файлов с помощью Tab: при нажатии на эту\n" +
                              "клавишу программа пытается дополнить введенный вами до этого путь. Функция находится в\n" +
                              "бета-тестировании, так что на данный момент в ней отключена возможность изменения\n" +
                              "уже введенных данных и поддерживаются только абсолютные пути (причем работает в рамках\n" +
                              "последнего слэша, т.е. .../ не изменится, а .../[часть названия папки/директории]\n" +
                              "изменится до максимального совпадения на данном уровне). Напоминаем, что в случае\n" +
                              "вашего нежелания выполнять выбранную вами операцию, вы можете закрыть приложение комбинацией\n" +
                              "Ctrl+C. Удачи!");
        }

        /// <summary>
        /// Обработка ввода.
        /// </summary>
        private static void GetOperation()
        {
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.F1)
                ViewDrives();
            else if (key.Key == ConsoleKey.F2)
                ViewDirectory();
            else if (key.Key == ConsoleKey.F3)
                ChangeDirectory();
            else if (key.Key == ConsoleKey.F4)
                ReadFile();
            else if (key.Key == ConsoleKey.F5)
                CopyFile();
            else if (key.Key == ConsoleKey.F6)
                MoveFile();
            else if (key.Key == ConsoleKey.F7)
                DeleteFile();
            else if (key.Key == ConsoleKey.F8)
                CreateFile();
            else if (key.Key == ConsoleKey.F9)
                ConcatFiles();
            else if (key.Key == ConsoleKey.F10)
                FindByMask();
            else if (key.Key == ConsoleKey.Escape)
                Environment.Exit(0);
            else
                ShowDescriptions();
        }

        /// <summary>
        /// Просмотр дисков.
        /// </summary>
        private static void ViewDrives()
        {
            Console.WriteLine("просмотр дисков.");
            DriveInfo[] drives = DriveInfo.GetDrives();
            for (var driveIndex = 0; driveIndex < drives.Length; driveIndex++)
                Console.WriteLine($"[drive] {drives[driveIndex].Name}");
            Console.WriteLine("-> Команда успешно выполнена.");
        }

        /// <summary>
        /// Просмотр каталога.
        /// </summary>
        private static void ViewDirectory()
        {
            Console.WriteLine("просмотр каталога.");
            var currentDirectory = Directory.GetCurrentDirectory();
            for (var i = 0; i < Directory.GetFiles(currentDirectory).Length; i++)
                Console.WriteLine($"[file] {Directory.GetFiles(currentDirectory)[i].Split("\\")[^1]}");
            for (var i = 0; i < Directory.GetDirectories(currentDirectory).Length; i++)
                Console.WriteLine($"[directory] {Directory.GetDirectories(currentDirectory)[i].Split("\\")[^1]}");
            Console.WriteLine("-> Команда успешно выполнена.");
        }

        /// <summary>
        /// Изменение текущей директории.
        /// </summary>
        private static void ChangeDirectory()
        {
            Console.WriteLine("изменение текущей директории.");
            while (true)
            {
                try
                {
                    Console.Write("-> Введите путь до новой текущей директории: ");
                    var path = $"{Console.ReadLine()}{Path.DirectorySeparatorChar}";
                    Directory.SetCurrentDirectory(path);
                    Console.WriteLine("-> Команда успешно выполнена.");
                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Вывод файла.
        /// </summary>
        private static void ReadFile()
        {
            Console.WriteLine("вывод файла.");
            while (true)
            {
                try
                {
                    Console.Write("-> Введите путь до файла без формата (к нему будет добавлен в конце .txt): ");
                    var path = $"{Console.ReadLine()}.txt";
                    if (!File.Exists(path))
                        throw new FileNotFoundException();
                    Console.Write("-> Укажите кодировку: ");
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    System.Text.Encoding encoding = key.Key switch
                    {
                        ConsoleKey.F1 => System.Text.Encoding.ASCII,
                        ConsoleKey.F2 => System.Text.Encoding.Unicode,
                        ConsoleKey.F3 => System.Text.Encoding.UTF32,
                        _ => System.Text.Encoding.UTF8,
                    };
                    Console.WriteLine(encoding.BodyName);
                    using StreamReader sr = new(path, encoding, false);
                    Console.WriteLine(sr.ReadToEnd());
                    Console.WriteLine("-> Команда успешно выполнена.");
                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Копирование файла.
        /// </summary>
        private static void CopyFile()
        {
            Console.WriteLine("копирование файла.");
            string pathFrom;
            string pathTo;
            while (true)
            {
                try
                {
                    Console.Write(
                        "-> Укажите cпособ ввода пути до исходного файла (F1 - экспериментальный, любая другая клавиша - обычный): ");
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (key.Key == ConsoleKey.F1)
                        pathFrom = ReadWithTab();
                    else
                    {
                        Console.Write("\n-> Введите путь до файла: ");
                        pathFrom = Console.ReadLine();
                    }

                    if (!File.Exists(pathFrom))
                        throw new FileNotFoundException();
                    Console.Write("-> Введите путь до директории копирования: ");
                    // Соединяем путь к директории и изначальное имя файла.
                    pathTo = $"{Console.ReadLine()}{Path.DirectorySeparatorChar}{Path.GetFileName(pathFrom)}";
                    File.Copy(pathFrom, pathTo, true);
                    Console.WriteLine("-> Команда успешно выполнена.");
                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Перемещение файла.
        /// </summary>
        private static void MoveFile()
        {
            Console.WriteLine("перемещение файла.");
            string pathFrom;
            while (true)
            {
                try
                {
                    Console.Write(
                        "-> Укажите cпособ ввода пути до исходного файла (F1 - экспериментальный, любая другая клавиша - обычный): ");
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (key.Key == ConsoleKey.F1)
                        pathFrom = ReadWithTab();
                    else
                    {
                        Console.Write("\n-> Введите путь до файла: ");
                        pathFrom = Console.ReadLine();
                    }

                    if (!File.Exists(pathFrom))
                        throw new FileNotFoundException();
                    Console.Write("-> Введите путь до директории перемещения: ");
                    var pathTo = $"{Console.ReadLine()}{Path.DirectorySeparatorChar}{Path.GetFileName(pathFrom)}";
                    if (!File.Exists(pathTo))
                        throw new FileNotFoundException();
                    File.Move(pathFrom, pathTo, true);
                    Console.WriteLine("-> Команда успешно выполнена.");
                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Удаление файла.
        /// </summary>
        private static void DeleteFile()
        {
            Console.WriteLine("удаление файла.");
            string path;
            while (true)
            {
                try
                {
                    Console.Write(
                        "-> Укажите cпособ ввода пути до файла (F1 - экспериментальный, любая другая клавиша - обычный): ");
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (key.Key == ConsoleKey.F1)
                        path = ReadWithTab();
                    else
                    {
                        Console.Write("\n-> Введите путь до файла: ");
                        path = Console.ReadLine();
                    }

                    if (!File.Exists(path))
                        throw new FileNotFoundException();
                    File.Delete(path);
                    Console.WriteLine("-> Команда успешно выполнена.");
                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Создание и запись файла.
        /// </summary>
        private static void CreateFile()
        {
            Console.WriteLine("создание файла.");
            while (true)
            {
                try
                {
                    Console.Write(
                        "-> Введите путь до нового/перезаписываемого файла без формата (к нему будет добавлен в конце .txt): ");
                    var path = $"{Console.ReadLine()}.txt";
                    Console.Write("-> Укажите кодировку: ");
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    System.Text.Encoding encoding = key.Key switch
                    {
                        ConsoleKey.F1 => System.Text.Encoding.ASCII,
                        ConsoleKey.F2 => System.Text.Encoding.Unicode,
                        ConsoleKey.F3 => System.Text.Encoding.UTF32,
                        _ => System.Text.Encoding.UTF8,
                    };
                    Console.WriteLine(encoding.BodyName);
                    using StreamWriter sw = new(path, false, encoding);
                    Console.WriteLine($"-> Введите текст для записи в файл (или пустую строку для завершения записи):");
                    var line = Console.ReadLine();
                    while (line != "")
                    {
                        sw.WriteLine(line);
                        line = Console.ReadLine();
                    }

                    Console.WriteLine("-> Команда успешно выполнена.");
                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Конкатенация файлов.
        /// </summary>
        private static void ConcatFiles()
        {
            Console.WriteLine("конкатенация файлов.");
            while (true)
            {
                try
                {
                    var text = new List<string>();
                    Console.WriteLine("-> Введите путь до файла без формата (к нему будет добавлен в конце .txt),\n" +
                                      "который участвует в конкатенации (или пустую строку для завершения записи, но до нее должно\n" +
                                      "быть хотя бы два файла!), результат сохранится в первом введенном файле в кодировке UTF-8:");
                    var path = Console.ReadLine();
                    var resultPath = $"{path}.txt";
                    // Читаем пути (запоминая первый) и записываем данные из файлов в text.
                    while (path != "")
                    {
                        using StreamReader sr = new($"{path}.txt");
                        text.Add(sr.ReadToEnd());
                        path = Console.ReadLine();
                    }

                    using (StreamWriter sw = new(resultPath, false, System.Text.Encoding.UTF8))
                        sw.Write(String.Join("\n", text));
                    Console.WriteLine(String.Join("\n", text));
                    Console.WriteLine("-> Команда успешно выполнена.");
                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Поиск по маске.
        /// </summary>
        private static void FindByMask()
        {
            Console.WriteLine("поиск по маске.");
            while (true)
            {
                try
                {
                    Console.Write("-> Введите маску (в формате маски для файлов, не регулярки!): ");
                    var mask = Console.ReadLine();
                    Console.Write("-> Нажмите на F1 для поиска по всем поддиректориям (false) и любую другую " +
                                  "клавишу для поиска только в директории (true): ");
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    var fullFind = SearchOption.TopDirectoryOnly;
                    if (key.Key == ConsoleKey.F1)
                        fullFind = SearchOption.AllDirectories;
                    Console.WriteLine(fullFind.Equals(SearchOption.TopDirectoryOnly));
                    var paths = Directory.GetFiles(Directory.GetCurrentDirectory(), mask, fullFind);
                    Console.WriteLine($"-> Команда успешно выполнена. Найдено файлов: {paths.Length}.");
                    if (paths.Length > 0)
                    {
                        Console.WriteLine(string.Join("\n", paths));
                        // Переход к методу копирования полученных файлов.
                        CopyFiles(paths);
                    }

                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Копирование файлов, найденных по маске.
        /// </summary>
        /// <param name="paths">Массив с абс. путями к файлам.</param>
        private static void CopyFiles(string[] paths)
        {
            Console.Write("-> Нажмите на F1 для копирования выбранных файлов (true) и любую другую " +
                          "клавишу для завершения операции (false): ");
            ConsoleKeyInfo key = Console.ReadKey(true);
            var flag = false;
            if (key.Key == ConsoleKey.F1)
                flag = true;
            Console.WriteLine(flag);
            if (!flag)
                return;
            while (true)
            {
                try
                {
                    Console.Write("-> Введите путь до директории копирования файлов: ");
                    var pathTo = Console.ReadLine();
                    if (!Directory.Exists(pathTo))
                        Directory.CreateDirectory(pathTo);
                    foreach (var path in paths)
                    {
                        var folder = $"{pathTo}{Path.DirectorySeparatorChar}" +
                                     $"{Path.GetDirectoryName(path)[Directory.GetCurrentDirectory().Length..]}";
                        if (!Directory.Exists(folder))
                            Directory.CreateDirectory(folder);
                        File.Copy(path, $"{folder}{Path.DirectorySeparatorChar}{Path.GetFileName(path)}", true);
                    }

                    Console.WriteLine("-> Команда успешно выполнена.");
                    break;
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                }
            }
        }

        /// <summary>
        /// Экспериментальное чтение строки с Tab.
        /// </summary>
        /// <returns>Полученная строка.</returns>
        private static string ReadWithTab()
        {
            Console.WriteLine("\nЭКСПЕРИМЕНТАЛЬНЫЙ ВВОД!");
            var input = new List<char>();
            ConsoleKeyInfo key = Console.ReadKey(true);
            while (key.Key != ConsoleKey.Enter)
            {
                if (key.Key == ConsoleKey.Tab)
                    CompleteInput(ref input);
                // Отключаем клавиши типа Backspace и т.д.
                else if (key.KeyChar > 31)
                {
                    Console.Write(key.KeyChar);
                    input.Add(key.KeyChar);
                }

                key = Console.ReadKey(true);
            }

            string path = new(input.ToArray());
            Console.WriteLine();
            return path;
        }

        /// <summary>
        /// Дополнение строки Tab'ом.
        /// </summary>
        /// <param name="line">Список символов в консоли.</param>
        private static void CompleteInput(ref List<char> line)
        {
            string path = new(line.ToArray());
            string newLine;
            try
            {
                // Проверка на абсолютность путя.
                if (Path.IsPathRooted(path) && Directory.Exists(Path.GetDirectoryName(path)))
                {
                    var part = Path.GetFileName(path);
                    // Создаем маску и ищем по ней подходящие файлы.
                    string[] matches = Directory.GetFiles(Path.GetDirectoryName(path), $"{part}*")
                        .Concat(Directory.GetDirectories(Path.GetDirectoryName(path), $"{part}*")).ToArray();
                    Array.Sort(matches);
                    line = new List<char>();
                    // Ищем общую часть файлов.
                    for (var index = 0; index < matches[0].Length; index++)
                    {
                        foreach (var match in matches)
                            if (match[index] != matches[0][index])
                            {
                                Console.Write("\n-> Умный дописыватель сработал!\n");
                                newLine = new(line.ToArray());
                                foreach (var elem in newLine)
                                    Console.Write(elem);
                                return;
                            }

                        line.Add(matches[0][index]);
                    }
                    Console.Write("\n-> Умный дописыватель сработал!\n");
                    newLine = new(line.ToArray());
                    foreach (var elem in newLine)
                        Console.Write(elem);
                }
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Обработка ошибок.
        /// </summary>
        /// <param name="ex">Ошибка.</param>
        private static void ShowException(Exception ex)
        {
            string message = ex switch
            {
                PathTooLongException => "[слишком длинный путь]",
                UnauthorizedAccessException => "[ошибка доступа]",
                DirectoryNotFoundException => "[директория не найдена]",
                FileNotFoundException => "[файл не найден]",
                IOException => "[ошибка ввода-вывода]",
                _ => $"[{ex.GetType()}]",
            };
            Console.WriteLine($"Ошибка! {message}, повторите еще раз!");
        }
    }
}