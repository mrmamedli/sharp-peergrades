﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace NotepadSE
{
    /// <summary>
    /// Расширение класса TabPage.
    /// </summary>
    public class FileTab : TabPage
    {
        /// <summary>
        /// Путь до файла в вкладке.
        /// </summary>
        public string TabPath = null;

        /// <summary>
        /// Наличие несохраненных изменений.
        /// </summary>
        public bool Changes = false;

        /// <summary>
        /// Элемент для работы с файлами.
        /// </summary>
        public RichTextBox TabTextBox = new();

        /// <summary>
        /// С помощью данного поля каждой вкладке присваивается уникальный id вкладки.
        /// </summary>
        private static int s_id = 0;

        /// <summary>
        /// Создание вкладки.
        /// </summary>
        /// <param name="path">Путь до файла.</param>
        public FileTab(string path=null) : base()
        {
            TabPath = path;
            TabTextBox.Name = "richTextBox";
            Controls.Add(TabTextBox);
            TabTextBox.Dock = DockStyle.Fill;
            Text = (string.IsNullOrEmpty(path)) ? $"new - {s_id}" : Path.GetFileName(path);
            s_id++;
            if (!string.IsNullOrEmpty(path))
            {
                using var currentFile = new StreamReader(path);
                if (Path.GetExtension(path) == ".rtf")
                    TabTextBox.Rtf = currentFile.ReadToEnd();
                else
                    TabTextBox.Text = currentFile.ReadToEnd();
            }
            TabTextBox.TextChanged += new EventHandler(Changed);
            TabTextBox.FontChanged += new EventHandler(Changed);
            TabTextBox.StyleChanged += new EventHandler(Changed);
        }

        /// <summary>
        /// Изменения файла.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        public void Changed(object sender, EventArgs e)
        {
            Changes = true;
        }

        /// <summary>
        /// Сохранение файла.
        /// </summary>
        public void Save()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(TabPath));
            if (Path.GetExtension(TabPath) == ".rtf")
            {
                File.Create(TabPath).Close();
                TabTextBox.SaveFile(TabPath);
            }
            else
            {
                using StreamWriter file = new(TabPath);
                file.Write(TabTextBox.Text);
            }
            Changes = false;
        }
    }
}
