﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotepadSE
{
    /// <summary>
    /// Класс, отвечающий за основное окно приложения.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// Инициализация окна.
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Загрузка окна - добавление вкладок.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void FormLoad(object sender, EventArgs e)
        {
            try
            {
                Width = Properties.Settings.Default.width;
                Height = Properties.Settings.Default.height;
                tabControl.TabPages.Clear();
                var tabs = Properties.Settings.Default.tabs;
                foreach (var path in tabs)
                {
                    try
                    {
                        var tab = new FileTab(path);
                        tab.TabTextBox.ContextMenuStrip = contextMenuStrip;
                        tabControl.TabPages.Add(tab);
                    }
                    catch
                    {
                        // Файл недоступен или удален.
                    }
                }
                Properties.Settings.Default.tabs.Clear();
                Properties.Settings.Default.Save();
                if (tabControl.TabPages.Count == 0)
                {
                    var newTab = new FileTab();
                    newTab.TabTextBox.ContextMenuStrip = contextMenuStrip;
                    tabControl.TabPages.Add(newTab);
                }

                theme.SelectedIndex = Properties.Settings.Default.themeId;
                saveTime.SelectedIndex = Properties.Settings.Default.saveTimeId;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Создание пустой вкладки.
        /// </summary>
        private void CreateNewFile()
        {
            var tab = new FileTab();
            tab.TabTextBox.ContextMenuStrip = contextMenuStrip;
            tabControl.TabPages.Add(tab);
            tabControl.SelectTab(tabControl.TabPages.Count - 1);
            SetTheme(theme.SelectedIndex);

        }

        /// <summary>
        /// Перенаправление на создание пустой вкладки.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void NewFile(object sender, EventArgs e)
        {
            try
            {
                CreateNewFile();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Открытие файла.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void OpenFile(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog.ShowDialog() != DialogResult.Cancel)
                {
                    var path = openFileDialog.FileName;
                    var tab = new FileTab(path);
                    tab.TabTextBox.ContextMenuStrip = contextMenuStrip;
                    tabControl.TabPages.Add(tab);
                    tabControl.SelectTab(tabControl.TabPages.Count - 1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Сохранение вкладки по индексу.
        /// </summary>
        /// <param name="i">Индекс вкладки.</param>
        private bool SaveTab(int i)
        {
            var tab = tabControl.TabPages[i] as FileTab;
            try
            {
                tab.Save();
            }
            catch
            {
                try
                {
                    saveFileDialog.FileName = Path.GetFileNameWithoutExtension(tab.Text);
                    if (saveFileDialog.ShowDialog() == DialogResult.Cancel)
                        return false;
                    tab.TabPath = saveFileDialog.FileName;
                    tab.Text = Path.GetFileName(saveFileDialog.FileName);
                    tab.Save();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Сохранение файла в активной вкладке.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void SaveFile(object sender, EventArgs e)
        {
            try
            {
                SaveTab(tabControl.SelectedIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Сохранение файла в активной вкладке по другому пути.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void SaveAs(object sender, EventArgs e)
        {
            try
            {
                var tab = tabControl.SelectedTab as FileTab;
                saveFileDialog.FileName = tab.Text;
                if (saveFileDialog.ShowDialog() != DialogResult.Cancel)
                {
                    tab.TabPath = saveFileDialog.FileName;
                    tab.Text = Path.GetFileName(saveFileDialog.FileName);
                    tab.Save();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Сохранение и закрытие вкладки по индексу.
        /// </summary>
        /// <param name="i">Индекс вкладки.</param>
        private void SaveAndClose(int i)
        {
            try
            {
                var tab = tabControl.TabPages[i] as FileTab;
                if (tab.Changes)
                {
                    var result = MessageBox.Show("Сохранить файл перед закрытием?", "Закрытие", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Stop);
                    if (result == DialogResult.Cancel)
                        return;
                    else if (result == DialogResult.Yes)
                        if (!SaveTab(i))
                            return;
                }
                tabControl.TabPages.RemoveAt(i);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Сохранение файлов в всех вкладках.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void SaveAll(object sender, EventArgs e)
        {
            try
            {
                for (var i = tabControl.TabPages.Count - 1; i >= 0; i--)
                    SaveTab(i);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Закрытие активной вкладки.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void CloseFile(object sender, EventArgs e)
        {
            try
            {
                SaveAndClose(tabControl.SelectedIndex);
                if (tabControl.TabPages.Count == 0)
                    CreateNewFile();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Закрытие всех вкладок.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void CloseAll(object sender, EventArgs e)
        {
            try
            {
                for (var i = tabControl.TabPages.Count - 1; i >= 0; i--)
                    SaveAndClose(i);
                if (tabControl.TabPages.Count == 0)
                    CreateNewFile();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Запуск копии приложения.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void CreateForm(object sender, EventArgs e)
        {
            try
            {
                Process.Start(Application.ExecutablePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Перенаправление на метод выхода.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void Exit(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Выход из активного окна приложения.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void CloseForm(object sender, FormClosingEventArgs e)
        {
            try
            {
                Properties.Settings.Default.width = Width;
                Properties.Settings.Default.height = Height;
                Properties.Settings.Default.tabs.Clear();
                foreach (var tab in tabControl.TabPages)
                {
                    Properties.Settings.Default.tabs.Add((tab as FileTab).TabPath);
                }
                Properties.Settings.Default.Save();

                for (var i = tabControl.TabPages.Count - 1; i >= 0; i--)
                    SaveAndClose(i);
                if (tabControl.TabPages.Count != 0)
                    e.Cancel = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Отмена действия.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void Undo(object sender, EventArgs e)
        {
            try
            {
                var tab = tabControl.SelectedTab as FileTab;
                tab.TabTextBox.Undo();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Возвращение действия.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void Redo(object sender, EventArgs e)
        {
            try
            {
                var tab = tabControl.SelectedTab as FileTab;
                tab.TabTextBox.Redo();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Вырезка выделения.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void Cut(object sender, EventArgs e)
        {
            try
            {
                var tab = tabControl.SelectedTab as FileTab;
                tab.TabTextBox.Cut();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Копирование выделения.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void Copy(object sender, EventArgs e)
        {
            try
            { 
                var tab = tabControl.SelectedTab as FileTab;
                tab.TabTextBox.Copy();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Вставка выделения.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void Paste(object sender, EventArgs e)
        {
            try
            {
                var tab = tabControl.SelectedTab as FileTab;
                tab.TabTextBox.Paste();
            }
            catch (Exception ex) 
            { 
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Выделение всего текста.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void SelectAll(object sender, EventArgs e)
        {
            try
            {
                var tab = tabControl.SelectedTab as FileTab;
                tab.TabTextBox.SelectAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
}

        /// <summary>
        /// Выбор шрифта.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void SetFont(object sender, EventArgs e)
        {
            try
            {

                var tab = tabControl.SelectedTab as FileTab;
                if ((fontDialog.ShowDialog() != DialogResult.Cancel))
                {
                    tab.TabTextBox.SelectionFont = fontDialog.Font;
                    tab.TabTextBox.SelectionColor = fontDialog.Color;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Изменение темы после смены ее в настройках.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void ChangeTheme(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.themeId = theme.SelectedIndex;
                Properties.Settings.Default.Save();
                SetTheme(theme.SelectedIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
}

        /// <summary>
        /// Отрисовка темы.
        /// </summary>
        /// <param name="i">Индекс темы.</param>
        private void SetTheme(int i)
        {
            try
            {
                var menuColor = i switch
                {
                    1 => Color.LightBlue,
                    2 => Color.LemonChiffon,
                    3 => Color.Pink,
                    _ => Color.LightGray
                };
                var textBoxColor = i switch
                {
                    1 => Color.AliceBlue,
                    2 => Color.Cornsilk,
                    3 => Color.LavenderBlush,
                    _ => Color.White
                };
                var color = i switch
                {
                    1 => Color.CadetBlue,
                    2 => Color.DarkKhaki,
                    3 => Color.PaleVioletRed,
                    _ => Color.Gray
                };
                menuStrip.BackColor = menuColor;
                fileToolStripMenuItem.DropDown.BackColor = menuColor;
                editToolStripMenuItem.DropDown.BackColor = menuColor;
                formatToolStripMenuItem.DropDown.BackColor = menuColor;
                settingsToolStripMenuItem.DropDown.BackColor = menuColor;
                themeToolStripMenuItem.DropDown.BackColor = menuColor;
                autosaveToolStripMenuItem.DropDown.BackColor = menuColor;
                aboutToolStripMenuItem.DropDown.BackColor = menuColor;
                BackColor = color;
                statusStrip.BackColor = color;
                contextMenuStrip.BackColor = color;
                (tabControl.SelectedTab as FileTab).TabTextBox.BackColor = textBoxColor;
            }
            catch
            {
                // Ошибка вылезает, когда мы удаляем последнюю вкладку, потому что невозможна перекраска (от греха подальше закэтчим все).
            }
        }

        /// <summary>
        /// Изменение активной вкладки.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void TabChanged(object sender, EventArgs e)
        {
            try
            {
                SetTheme(theme.SelectedIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Изменение интервала таймера.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void SaveTimeChanged(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.saveTimeId = saveTime.SelectedIndex;
                Properties.Settings.Default.Save();
                if (saveTime.SelectedIndex == 0)
                {
                    timer.Enabled = false;
                }
                else
                {
                    timer.Enabled = true;
                    timer.Interval = int.Parse((saveTime.SelectedItem as String).Split()[0]) * 60000;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Тик таймера - сохраняем все, что можем.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void TimerTick(object sender, EventArgs e)
        {
            foreach (var tab in tabControl.TabPages)
            {
                try
                {
                    (tab as FileTab).Save();
                }
                catch
                {
                    // Если не получилось, ничего не делаем - пользователь просто заметит, что из названия не пропала звездочка.
                }
            }
        }

        /// <summary>
        /// Вывод справки.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void About(object sender, EventArgs e)
        {
            try
            {
                var about = new AboutForm();
                about.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
