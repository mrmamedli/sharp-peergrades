using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MessageService
{
    /// <summary>
    /// Статический класс с методами генерации пользователей/сообщений, сериализаций и десереализаций.
    /// </summary>
    public static class Methods
    {
        /// <summary>
        /// Генератор для рандомайзера.
        /// </summary>
        private static readonly Random RandomGenerator = new();
        
        /// <summary>
        /// Строка с символами для радомайзера.
        /// </summary>
        private const string Letters = "abcdefghijklmnopqrstuvwxyz";
        
        /// <summary>
        /// Путь к файлу с пользователями.
        /// </summary>
        private const string UsersPath = "Files/users.json";
        
        /// <summary>
        /// Путь к файлу с сообщениями.
        /// </summary>
        private const string MessagesPath = "Files/messages.json";
        
        /// <summary>
        /// Генератор пользователей.
        /// </summary>
        /// <returns>Список пользователей.</returns>
        public static List<User> GenerateUsers()
        {
            var users = new List<User>();
            var count = RandomGenerator.Next(1, 10);
            for (var i = 0; i < count; i++)
            {
                var name = new char[RandomGenerator.Next(6, 16)];
                for (var j = 0; j < name.Length; j++)
                {
                    name[j] = Letters[RandomGenerator.Next(0, Letters.Length)];
                }

                var userName = new string(name);
                
                var user = users.SingleOrDefault(user => user.Email == userName + "@hse.ru");

                if (user is not null)
                {
                    i--;
                    continue;
                }
                
                users.Add(new User {UserName = userName, Email = userName + "@hse.ru"});
            }

            return users;
        }
        
        /// <summary>
        /// Генератор сообщений.
        /// </summary>
        /// <param name="users">Список пользователей.</param>
        /// <returns>Список сообщений.</returns>
        public static List<TextMessage> GenerateMessages(List<User> users)
        {
            var messages = new List<TextMessage>();
            var count = RandomGenerator.Next(1, 15);
            for (var i = 0; i < count; i++)
            {
                var subject = new char[RandomGenerator.Next(6, 16)];
                for (var j = 0; j < subject.Length; j++)
                {
                    subject[j] = Letters[RandomGenerator.Next(0, Letters.Length)];
                }
                var message = new char[RandomGenerator.Next(1, 120)];
                for (var j = 0; j < message.Length; j++)
                {
                    message[j] = Letters[RandomGenerator.Next(0, Letters.Length)];
                }

                var fromId = users[RandomGenerator.Next(0, users.Count)].Email;
                var toId = users[RandomGenerator.Next(0, users.Count)].Email;
                messages.Add(new TextMessage{Subject = new string(subject), Message = new string(message), SenderId = fromId, ReceiverId = toId});
            }

            return messages;
        }

        /// <summary>
        /// Сериализация пользователей.
        /// </summary>
        /// <param name="users">Список пользователей.</param>
        /// <returns>Индикатор выполнения и строка вывода.</returns>
        public static (bool, string) SerializeList(List<User> users)
        {
            users.Sort((x, y) => string.CompareOrdinal(x.Email, y.Email));
            try
            {
                var jsonString = JsonSerializer.Serialize(users);
                File.WriteAllText(UsersPath, jsonString);
                return (true, "Данные успешно сохранены!");
            }
            catch (Exception e)
            {
                return (false, $"Возникла ошибка! {e.Message}");
            }
        }
        
        /// <summary>
        /// Сериализация сообщений.
        /// </summary>
        /// <param name="messages">Список сообщений.</param>
        /// <returns>Индикатор выполнения и строка вывода.</returns>
        public static (bool, string) SerializeList(List<TextMessage> messages)
        {
            try
            {
                var jsonString = JsonSerializer.Serialize(messages);
                File.WriteAllText(MessagesPath, jsonString);
                return (true, "Данные успешно сохранены!");
            }
            catch (Exception e)
            {
                return (false, $"При записи возникла ошибка! {e.Message}");
            }
        }
        
        /// <summary>
        /// Десериализация пользователя.
        /// </summary>
        /// <returns>Индикатор выполнения, строка вывода, список пользователей.</returns>
        public static (bool, string, List<User>) DeserializeUsers()
        {
            var users = new List<User>();
            try
            {
                var jsonString = File.ReadAllText(UsersPath);
                users = JsonSerializer.Deserialize<List<User>>(jsonString);
                return (true, "Данные успешно получены!", users);
            }
            catch (Exception e)
            {
                return (false, $"При чтении возникла ошибка! {e.Message}", users);
            }
        }
        
        /// <summary>
        /// Десериализация сообщений.
        /// </summary>
        /// <returns>Индикатор выполнения, строка вывода, список сообщений.</returns>
        public static (bool, string, List<TextMessage>) DeserializeMessages()
        {
            var messages = new List<TextMessage>();
            try
            {
                var jsonString = File.ReadAllText(MessagesPath);
                messages = JsonSerializer.Deserialize<List<TextMessage>>(jsonString);
                return (true, "Данные успешно получены!", messages);
            }
            catch (Exception e)
            {
                return (false, $"При чтении возникла ошибка! {e.Message}", messages);
            }
        }
    }
}