using System.ComponentModel.DataAnnotations;

namespace MessageService
{
    /// <summary>
    /// Класс пользователя.
    /// </summary>
    public class User
    {
        /// <summary>
        /// Имя пользователя.
        /// </summary>
        [Required]
        public string UserName { get; set; }
        
        /// <summary>
        /// Почтовый адрес.
        /// </summary>
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}