using System.ComponentModel.DataAnnotations;

namespace MessageService
{
    /// <summary>
    /// Класс сообщения.
    /// </summary>
    public class TextMessage
    {
        /// <summary>
        /// Тема сообщения.
        /// </summary>
        [Required]
        public string Subject { get; set; }
        
        /// <summary>
        /// Содержание сообщения.
        /// </summary>
        [Required]
        public string Message { get; set; }
        
        /// <summary>
        /// Адрес отправителя.
        /// </summary>
        [Required]
        [EmailAddress]
        public string SenderId { get; set; }
        
        /// <summary>
        /// Адрес получателя.
        /// </summary>
        [Required]
        [EmailAddress]
        public string ReceiverId { get; set; }
    }
}