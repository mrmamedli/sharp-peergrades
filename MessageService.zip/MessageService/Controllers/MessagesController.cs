﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

using static MessageService.Methods;

namespace MessageService.Controllers
{
    /// <summary>
    /// Контроллер с обработчиками сообщений.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class MessagesController : ControllerBase
    {
        /// <summary>
        /// Получение всех сообщений.
        /// </summary>
        /// <returns>Список сообщений или ошибка 400.</returns>
        [HttpGet("all-messages")]
        [ProducesResponseType(typeof(List<TextMessage>), 200)]
        [ProducesResponseType(400)]
        public IActionResult GetMessages()
        {
            var (indicator, output, messages) = DeserializeMessages();
            if (indicator)
            {
                return Ok(messages);
            }

            return BadRequest(output);
        }
        
        /// <summary>
        /// Получение сообщений от отправителя получателю.
        /// </summary>
        /// <param name="fromId">Почтовый адрес отправителя.</param>
        /// <param name="toId">Почтовый адрес получателя.</param>
        /// <returns>Список сообщений или ошибка 400 или ошибка 404.</returns>
        [HttpGet("fromto")]
        [ProducesResponseType(typeof(IEnumerable<TextMessage>), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult GetMessagesFromTo([Required, FromQuery] string fromId, [Required, FromQuery] string toId)
        {
            var (indicator, output, messages) = DeserializeMessages();
            if (!indicator)
            {
                return BadRequest(output);
            }
            
            var selectedMessages = messages.Where(message => 
                message.SenderId == fromId && message.ReceiverId == toId);

            if (!selectedMessages.Any())
            {
                return NotFound("Сообщения не найдены!");
            }

            return Ok(selectedMessages);
        }
        
        /// <summary>
        /// Получение сообщений от отправителя.
        /// </summary>
        /// <param name="fromId">Почтовый адрес отправителя.</param>
        /// <returns>Список сообщений или ошибка 400 или ошибка 404.</returns>
        [HttpGet("from")]
        [ProducesResponseType(typeof(IEnumerable<TextMessage>), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult GetMessagesFrom([Required, FromQuery] string fromId)
        {
            var (indicator, output, messages) = DeserializeMessages();
            if (!indicator)
            {
                return BadRequest(output);
            }
            
            var selectedMessages = messages.Where(message => 
                message.SenderId == fromId);

            if (!selectedMessages.Any())
            {
                return NotFound("Сообщения не найдены!");
            }

            return Ok(selectedMessages);
        }
        
        /// <summary>
        /// Получение сообщений получателю.
        /// </summary>
        /// <param name="toId">Почтовый адрес получателя.</param>
        /// <returns>Список сообщений или ошибка 400 или ошибка 404.</returns>
        [HttpGet("to")]
        [ProducesResponseType(typeof(IEnumerable<TextMessage>), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult GetMessagesTo([Required, FromQuery] string toId)
        {
            var (indicator, output, messages) = DeserializeMessages();
            if (!indicator)
            {
                return BadRequest(output);
            }
            
            var selectedMessages = messages.Where(message => 
                message.ReceiverId == toId);

            if (!selectedMessages.Any())
            {
                return NotFound("Сообщения не найдены!");
            }

            return Ok(selectedMessages);
        }
        
        /// <summary>
        /// Добавление сообщений.
        /// </summary>
        /// <param name="newMessage">Сообщение.</param>
        /// <returns>Результат добавления.</returns>
        [HttpPost("add-message")]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult AddMessage([FromForm] TextMessage newMessage)
        {
            var messages = new List<TextMessage>();
            var (indicator, output, users) = DeserializeUsers();
            if (!indicator)
            {
                return BadRequest(output);
            }
            (indicator, output, messages) = DeserializeMessages();
            if (!indicator)
            {
                return BadRequest(output);
            }

            if (users.SingleOrDefault(user => user.Email == newMessage.SenderId) is null ||
                users.SingleOrDefault(user => user.Email == newMessage.ReceiverId) is null)
            {
                return NotFound("Не найден отправитель и (или) получатель!");
            }
            messages.Add(newMessage);
            (indicator, output) = SerializeList(messages);
            if (!indicator)
            {
                return BadRequest(output);
            }
            return Ok("Сообщение добавлено!");
        }
    }
}