using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

using static MessageService.Methods;

namespace MessageService.Controllers
{
    /// <summary>
    /// Контроллер с обработчиками пользователей.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class UsersController : Controller
    {
        /// <summary>
        /// Получение всех пользователей.
        /// </summary>
        /// <returns>Список пользователей или ошибка 400.</returns>
        [HttpGet("all-users")]
        [ProducesResponseType(typeof(List<User>), 200)]
        [ProducesResponseType(400)]
        public IActionResult GetUsers()
        {
            var (indicator, output, users) = DeserializeUsers();
            if (indicator)
            {
                return Ok(users);
            }

            return BadRequest(output);
        }
        
        /// <summary>
        /// Получение пользователя по его почтовому адресу.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Пользователь или ошибка 400 или ошибка 404.</returns>
        [HttpGet("user")]
        [ProducesResponseType(typeof(User), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public IActionResult GetUserWithId([Required, FromQuery] string id)
        {
            var (indicator, output, users) = DeserializeUsers();
            if (!indicator)
            {
                return BadRequest(output);
            }
            
            var user = users.SingleOrDefault(user => user.Email == id);

            if (user is null)
            {
                return NotFound("Пользователи не найдены!");
            }

            return Ok(user);
        }
        
        /// <summary>
        /// Получение всех пользователей на странице.
        /// </summary>
        /// <param name="limit">Максимальное количество пользователей.</param>
        /// <param name="offset">Индекс первого пользователя.</param>
        /// <returns>Список пользователей или ошибка 400.</returns>
        [HttpGet("users-page")]
        [ProducesResponseType(typeof(IEnumerable<User>), 200)]
        [ProducesResponseType(400)]
        public IActionResult GetUsersPage([Required, FromQuery] int limit, [Required, FromQuery] int offset)
        {
            if (limit <= 0 || offset < 0)
            {
                return BadRequest("Некорректные ограничения!");
            }
            var (indicator, output, users) = DeserializeUsers();
            if (indicator)
            {
                return Ok(users.Skip(offset).Take(limit));
            }

            return BadRequest(output);
        }
        
        /// <summary>
        /// Добавление пользователя.
        /// </summary>
        /// <param name="newUser">Пользователь.</param>
        /// <returns>Результат добавления.</returns>
        [HttpPost("add-user")]
        [ProducesResponseType(typeof(IEnumerable<User>), 200)]
        [ProducesResponseType(400)]
        public IActionResult AddUser([FromForm] User newUser)
        {
            var (indicator, output, users) = DeserializeUsers();
            if (!indicator)
            {
                return BadRequest(output);
            }
            if (users.SingleOrDefault(user => user.Email == newUser.Email) is not null)
            {
                return BadRequest("Такой пользователь уже существует!");
            }
            users.Add(newUser);
            (indicator, output) = SerializeList(users);
            if (!indicator)
            {
                return BadRequest(output);
            }
            return Ok("Пользователь добавлен!");
        }
    }
}