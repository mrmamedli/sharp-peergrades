using Microsoft.AspNetCore.Mvc;

using static MessageService.Methods;

namespace MessageService.Controllers
{
    /// <summary>
    /// Контроллер с обработчиком генерации.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class ServiceController : Controller
    {
        /// <summary>
        /// Обработчик для генерации пользователей и сообщений.
        /// </summary>
        /// <returns>Сообщение с </returns>
        [HttpPost("randomize")]
        [ProducesResponseType(typeof(string), 200)]
        [ProducesResponseType(400)]
        public IActionResult Randomize()
        {
            var users = GenerateUsers();
            var (indicator, output) = SerializeList(users);
            if (!indicator)
            {
                return BadRequest(output);
            }
            var messages = GenerateMessages(users);
            (indicator, output) = SerializeList(messages);
            if (!indicator)
            {
                return BadRequest(output);
            }
            return Ok("Пользователи и сообщения сгенерированы!");
        }
    }
}