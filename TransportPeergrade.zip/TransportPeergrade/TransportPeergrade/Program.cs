﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using EKRLib;

namespace TransportPeergrade
{
    /// <summary>
    /// Консольная программа для генерации набора транспорта и сохранения в файлы.
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Поле для генерации случайных чисел.
        /// </summary>
        private static readonly Random Rnd = new();

        /// <summary>
        /// Точка старта программы.
        /// </summary>
        private static void Main()
        {
            while (true)
            {
                var transportsCount = Rnd.Next(6, 10);
                var transports = new Transport[transportsCount];
                Console.WriteLine("-> Начинаем генерацию транспортных средств!");
                Console.WriteLine($"-> Количество транспортных средств: {transportsCount}.");
                GenerateTransports(ref transports);
                Console.WriteLine("-> Транспорт сгенерирован! Начинаем запись в файлы.");
                WriteToFile(transports);
                Console.WriteLine("-> Работа завершена!");
                Restart();
            }
        }

        /// <summary>
        /// Метод для генерации транспорта.
        /// </summary>
        /// <param name="transports">Массив для хранения транспорта.</param>
        private static void GenerateTransports(ref Transport[] transports)
        {
            for (var i = 0; i < transports.Length; i++)
            {
                try
                {
                    var ind = Rnd.Next(0, 2);
                    var model = "";
                    for (var j = 0; j < 5; j++)
                    {
                        model += Transport.Symbols[Rnd.Next(0, Transport.Symbols.Length)];
                    }
                    if (ind == 0)
                    {
                        transports[i] = new Car(model, (uint) Rnd.Next(10, 100));
                    }
                    else
                    {
                        transports[i] = new MotorBoat(model, (uint) Rnd.Next(10, 100));
                    }
                    Console.WriteLine(transports[i].StartEngine());
                }
                catch (TransportException e)
                {
                    i--;
                    Console.WriteLine($"Ошибка при генерации! -> {e.Message}");
                }
            }
        }

        /// <summary>
        /// Метод для записи информации о транспорте в файлы.
        /// </summary>
        /// <param name="transports">Массив для хранения транспорта.</param>
        private static void WriteToFile(Transport[] transports)
        {
            var cars = new List<string>();
            var motorBoats = new List<string>();
            foreach (var transport in transports)
            {
                if (transport is Car)
                {
                    cars.Add(transport.ToString());
                }
                else
                {
                    motorBoats.Add(transport.ToString());
                }
            }
            try
            {
                using (StreamWriter sw = new("../../../../Cars.txt", false, Encoding.Unicode))
                {
                    sw.Write(string.Join("\n", cars.ToArray()));
                }
                using (StreamWriter sw = new("../../../../MotorBoats.txt", false, Encoding.Unicode))
                {
                    sw.Write(string.Join("\n", motorBoats.ToArray()));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Ошибка -> {e.Message}");
            }
        }

        /// <summary>
        /// Метод для перезапуска файла.
        /// </summary>
        private static void Restart()
        {
            Console.WriteLine("-------------------");
            Console.WriteLine("-> Для перезапуска приложения нажмите на Enter, для завершения - на любую другую.");
            if (Console.ReadKey().Key == ConsoleKey.Enter)
            {
                Console.Clear();
                return;
            }
            Environment.Exit(0);
        }
    }
}