﻿using System.Linq;

namespace EKRLib
{
    /// <summary>
    /// Описание абстрактного транспортного средства.
    /// </summary>
    public abstract class Transport
    {
        /// <summary>
        /// Строка возможных символов для Model.
        /// </summary>
        public static readonly string Symbols = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        
        /// <summary>
        /// Поле, хранящее информацию о модели транспортного средства.
        /// </summary>
        private string _model;

        /// <summary>
        /// Свойство для получения и изменения модели.
        /// </summary>
        /// <exception cref="TransportException">Исключение возникает при несоответствии требуемым к модели параметрам.</exception>
        protected string Model
        {
            get => _model;
            set
            {
                if (value.Length != 5 || value.Any(el => !Symbols.Contains(el)))
                {
                    throw new TransportException($"Недопустимая модель {value}");
                }
                _model = value;
            }
        }
        
        /// <summary>
        /// Поле, хранящее информацию о мощности в лошадиных силах транспортного средства.
        /// </summary>
        private uint _power;

        /// <summary>
        /// Свойство для получения и изменения мощности в лошадиных силах.
        /// </summary>
        /// <exception cref="TransportException">Исключение возникает при несоответствии требуемым к мощности параметрам.</exception>
        protected uint Power
        {
            get => _power;
            set
            {
                if (value < 20)
                {
                    throw new TransportException("Мощность не может быть меньше 20 л.с.");
                }
                _power = value;
            }
        }

        /// <summary>
        /// Строковое представление транспорта.
        /// </summary>
        /// <returns>Строка с описанием транспорта.</returns>
        public override string ToString() => $"Model: {Model}, Power: {Power}";

        /// <summary>
        /// Переопределяемый метод для получения звука транспорта.
        /// </summary>
        /// <returns>Строковое представление звука, издаваемого транспортом.</returns>
        public abstract string StartEngine();

        /// <summary>
        /// Конструктор транспорта.
        /// </summary>
        /// <param name="model">Строка - модель транспорта.</param>
        /// <param name="power">Число - мощность транспорта.</param>
        public Transport(string model, uint power)
        {
            Model = model;
            Power = power;
        }
    }
}