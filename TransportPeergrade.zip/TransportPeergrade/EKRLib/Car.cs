namespace EKRLib
{
    /// <summary>
    /// Описание автомобиля.
    /// </summary>
    public class Car: Transport
    {
        /// <summary>
        /// Конструктор автомобиля.
        /// </summary>
        /// <param name="model">Строка - модель автомобиля.</param>
        /// <param name="power">Число - мощность автомобиля.</param>
        public Car(string model, uint power) : base(model, power) { }

        /// <summary>
        /// Строковое представление автомобиля.
        /// </summary>
        /// <returns>Строка с описанием автомобиля.</returns>
        public override string ToString() => "Car. " + base.ToString();

        /// <summary>
        /// Метод для получения звука автомобиля.
        /// </summary>
        /// <returns>Строковое представление звука, издаваемого автомобилем.</returns>
        public override string StartEngine() => $"{Model}: Vroom";
    }
}