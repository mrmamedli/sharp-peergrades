using System;
using System.Runtime.Serialization;

namespace EKRLib
{
    /// <summary>
    /// Класс исключения, связанного с ошибкой создания транспортного средства.
    /// </summary>
    public class TransportException: Exception
    {
        /// <summary>
        /// Конструктор (Инициализирует новый экземпляр класса TransportException).
        /// </summary>
        public TransportException() { }

        /// <summary>
        /// Конструктор (Инициализирует новый экземпляр класса TransportException с указанным сообщением об ошибке).
        /// </summary>
        /// <param name="message">Сообщение об ошибке.</param>
        public TransportException(string message) : base(message) { }

        /// <summary>
        /// Конструктор (Инициализирует новый экземпляр класса TransportException указанным сообщением об ошибке
        /// и ссылкой на внутреннее исключение, вызвавшее данное исключение).
        /// </summary>
        /// <param name="message">Сообщение об ошибке.</param>
        /// <param name="inner">Ссылка на внутреннее исключение.</param>
        public TransportException(string message, Exception inner) : base(message, inner) { }
        
        /// <summary>
        /// Конструктор (Инициализирует новый экземпляр класса Exception с сериализованными данными).
        /// </summary>
        /// <param name="info">Информация.</param>
        /// <param name="context">Контекст.</param>
        public TransportException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}