namespace EKRLib
{
    /// <summary>
    /// Описание моторной лодки.
    /// </summary>
    public class MotorBoat: Transport
    {
        /// <summary>
        /// Конструктор моторной лодки.
        /// </summary>
        /// <param name="model">Строка - модель моторной лодки.</param>
        /// <param name="power">Число - мощность моторной лодки.</param>
        public MotorBoat(string model, uint power) : base(model, power) { }
        
        /// <summary>
        /// Строковое представление моторной лодки.
        /// </summary>
        /// <returns>Строка с описанием моторной лодки.</returns>
        public override string ToString() => "MotorBoat. " + base.ToString();

        /// <summary>
        /// Метод для получения звука моторной лодки.
        /// </summary>
        /// <returns>Строковое представление звука, издаваемого моторной лодкой.</returns>
        public override string StartEngine() => $"{Model}: Brrrbrr";
    }
}