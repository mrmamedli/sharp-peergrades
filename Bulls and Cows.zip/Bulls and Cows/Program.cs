﻿using System;

namespace Bulls_and_Cows
{
    /// <summary>
    /// Класс, реализующий консольную игру "Быки и коровы".
    /// </summary>
    class BullsAndCows
    {
        /// <summary>
        /// Точка входа; выводит правила, после чего запускает первую игру.
        /// </summary>
        static void Main()
        {
            Console.WriteLine("------------------------>");
            Console.WriteLine("Вас приветствует консольная игра \"Быки и коровы\"!");
            Console.WriteLine("Правила игры:");
            Console.WriteLine("\t-> Пользователь вводит некоторое число N (1 <= N <= 10);");
            Console.WriteLine("\t-> Компьютер загадывает N-значное число, состоящее из неповторяющихся цифр");
            Console.WriteLine("\t   (оно не начинается с нуля);");
            Console.WriteLine("\t-> Пользователь, пытаясь угадать загаданное число, вводит N-значное число,");
            Console.WriteLine("\t   состоящее из неповторяющихся цифр (и не начинающееся с нуля);");
            Console.WriteLine("\t-> Компьютер выводит сообщение о том, сколько цифр (быков) угадано и находится");
            Console.WriteLine("\t   на своих местах, и сколько цифр (коров) угадано, но не расположено");
            Console.WriteLine("\t   на своих местах .");
            Console.WriteLine("\t   Вывод может выглядеть так: \"1A2B\", что значит \"один бык и две коровы\";");
            Console.WriteLine("\t-> Игра продолжается до тех пор, пока пользователь не угадает число");
            Console.WriteLine("\t   или не прервет игру.");
            Console.WriteLine("Команды пользователя:");
            Console.WriteLine("\t-> exit - выход из программы;");
            Console.WriteLine("\t-> restart - новая игра;");
            Console.WriteLine("!!!команды регистрозависимы, пишите их маленькими английскими буквами без ошибок!!!");
            Console.WriteLine("!!!не проставляйте лишние пробелы, программа может посчитать, что ввод неверный!!!");
            Console.WriteLine("Давайте начнем, удачи вам!");
            StartGame();
        }

        /// <summary>
        /// Начинает новую игру: спрашивает, сколько цифр будет в загаданном числе.
        /// </summary>
        static void StartGame()
        {
            Console.WriteLine("------------------------>");
            Console.WriteLine("-> Новая игра!");
            Console.Write("Пожалуйста, введите некоторое число N (1 <= N <= 10): ");
            var line = Console.ReadLine();
            // Цикл, каждую итерацию обрабатывающий ввод игрока, пока не будет введена команда exit
            // или число от 1 до 10.
            while (line != "exit")
            {
                // Перезагрузка игры не совершается, так как она (игра) еще не начата.
                if (line == "restart")
                    Console.WriteLine("-> Но вы еще не начали играть, зачем перезапускать игру?");
                // Проверяем, что введено число от 1 до 10.
                else if ((int.TryParse(line, out int digits)) && (1 <= digits) && (digits <= 10))
                {
                    Console.WriteLine($"-> Мы загадали {digits}-значное число! Попробуйте угадать его.");
                    Game(digits);
                }
                else
                    Console.WriteLine("Некорректный ввод, попробуйте еще раз!");

                Console.Write("Пожалуйста, введите некоторое число N (1 <= N <= 10): ");
                line = Console.ReadLine();
            }

            // Закрываем игру, если введена команда exit.
            Console.WriteLine("------------------------>");
            Console.WriteLine("Вы решили закончить игру. Будем ждать вас еще!");
            Environment.Exit(0);
        }

        /// <summary>
        /// Основной метод, отвечающий за текущую игру. Здесь происходит проверка ввода игрока, и,
        /// в зависимости от результата, вызывается соответствующий метод.
        /// </summary>
        /// <param name="digits">Количество цифр в загаданном числе.</param>
        static void Game(int digits)
        {
            // Создаем число, которое будет отгадывать игрок.
            string number = CreateNumber(digits);
            Console.Write($"Введите {digits}-значное число: ");
            // Переменная, содержащая ввод игрока в каждом раунде.
            var line = Console.ReadLine();
            // Цикл, каждую итерацию обрабатывающий ввод игрока, пока не будет введена команда exit.
            while (line != "exit")
            {
                // Перезагрузка игры.
                if (line == "restart")
                {
                    Console.WriteLine($"Давайте начнем сначала. В этой игре было загадано число {number}");
                    StartGame();
                }
                // Проверяем, что ввод пользователя корректен, под корректностью понимается то,
                // что ввод можно преобразовать в digits-значное число.
                else if ((line.Length > 0) && (line[0] != '0') && long.TryParse(line, out long userNumber)
                         && (Math.Pow(10, digits - 1) <= userNumber) && (userNumber < Math.Pow(10, digits)))
                    CheckNumber(line, number);
                else
                    Console.WriteLine("Некорректный ввод, попробуйте еще раз:)");

                Console.Write($"Введите {digits}-значное число: ");
                line = Console.ReadLine();
            }

            Console.WriteLine("------------------------>");
            Console.WriteLine("Вы решили закончить игру. Будем ждать вас еще!");
            Console.WriteLine("Удачного дня:)");
            Environment.Exit(0);
        }

        /// <summary>
        /// Генерирует число для новой игры и возвращает его в строковом виде.
        /// </summary>
        /// <param name="digits">Количество цифр в генерируемом числе.</param>
        /// <returns>Строка, которая содержит сгенерированное число для новой игры.</returns>
        static string CreateNumber(int digits)
        {
            // randomDigit содержит случайное число от 0 до 9.
            var rnd = new Random();
            var randomDigit = 0;
            // Генерируем первую цифру будущего число.
            while (randomDigit == 0)
                randomDigit = rnd.Next(10);
            // Переменная, содержащая создаваемое число в строковом виде.
            string strNumber = randomDigit.ToString();
            // Создаем остальные цифры для числа, проверяя, чтобы они не встречались ранее.
            while (strNumber.Length != digits)
            {
                randomDigit = rnd.Next(10);
                if (!(strNumber.Contains(randomDigit.ToString())))
                    strNumber += randomDigit;
            }

            return strNumber;
        }

        /// <summary>
        /// Проверяет на корректность число пользователя,
        /// в случае успеха выводит количество быков и коров и, при победе игрока,
        /// завершает текущую игру. В противном случае выводит сообщение об ошибке.
        /// </summary>
        /// <param name="userNumber">Число, введенное игроком, в строковом формате.</param>
        /// <param name="number">Загаданное компьютером число в строковом формате.</param>
        static void CheckNumber(string userNumber, string number)
        {
            // Переменные, содержащие количество коров и быков в числе.
            var cows = 0;
            var bulls = 0;
            // Проверяем каждую цифру введенного пользователем числа.
            for (var i = 0; i < userNumber.Length; i++)
            {
                // В правилах игры прописано, что число не должно содержать повторяющиеся цифры.
                if (userNumber.IndexOf(userNumber[i]) != userNumber.LastIndexOf(userNumber[i]))
                {
                    Console.WriteLine("Некорректный ввод, попробуйте еще раз:)");
                    return;
                }
                // Проверяем, есть ли выбранная цифра в загаданном числе и стоит ли она на своем месте.
                else if ((number.IndexOf(userNumber[i]) != -1) && (number.IndexOf(userNumber[i]) != i))
                    cows++;
                else if (number.IndexOf(userNumber[i]) == i)
                    bulls++;
            }

            Console.WriteLine($"-> Результат: {bulls}A{cows}B");
            // Проверяем, победил ли игрок.
            if (number == userNumber)
            {
                Console.WriteLine($"-> Вы победили!");
                AfterGame();
            }
        }

        /// <summary>
        /// Промежуточная стадия между играми. Игрок решает, продолжить игру или завершить.
        /// </summary>
        static void AfterGame()
        {
            Console.WriteLine("------------------------>");
            Console.WriteLine("-> Предлагаем начать игру заново!");
            Console.WriteLine("-> Для выхода введите команду exit, для новой игры - restart.");
            Console.Write($"Введите команду: ");
            var line = Console.ReadLine();
            // Цикл, обрабатывающий ввод игрока, пока не будет введена команда restart или exit.
            while (line != "exit")
            {
                // Новая игра.
                if (line == "restart")
                    StartGame();
                else
                    Console.WriteLine("Некорректный ввод, попробуйте еще раз:)");
                Console.Write($"Введите команду: ");
                line = Console.ReadLine();
            }

            Console.WriteLine("------------------------>");
            Console.WriteLine("Вы решили закончить игру. Будем ждать вас еще!");
            Environment.Exit(0);
        }
    }
}