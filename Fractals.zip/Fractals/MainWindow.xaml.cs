﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Fractals
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Начальная позиция перемещения холста.
        /// </summary>
        private (double, double) firstPosition;

        /// <summary>
        /// Размер стороны холста.
        /// </summary>
        private const double Side = 1000;

        /// <summary>
        /// Индикатор перемещения холста.
        /// </summary>
        private bool isMoving;

        /// <summary>
        /// Настройки зума холста.
        /// </summary>
        private ScaleTransform canvasZoom = new();

        /// <summary>
        /// Настройки перемещения холста.
        /// </summary>
        private TranslateTransform canvasTranslate = new();

        /// <summary>
        /// Инициация окна.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            Loaded += WindowLoaded;
        }

        /// <summary>
        /// Первая отрисовка фрактала, когда форма полностью создана.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void WindowLoaded(object sender, RoutedEventArgs e)
        {
            DrawFractal();
        }

        /// <summary>
        /// Изменение типа фрактала.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void TypeChanged(object sender, SelectionChangedEventArgs e)
        {
            if (mainCanvas is null)
                return;
            iterations.Value = 1;
            zoom.Value = 1;
            canvasTranslate = new TranslateTransform();
            mainCanvas.Children.Clear();
            treeSettings.Visibility = Visibility.Hidden;
            cantorSettings.Visibility = Visibility.Hidden;
            switch ((type.SelectedItem as ComboBoxItem)?.Name)
            {
                case "koch":
                    iterations.Maximum = 6;
                    break;
                case "carpet":
                    iterations.Maximum = 5;
                    break;
                case "triangle":
                    iterations.Maximum = 6;
                    break;
                case "cantor":
                    iterations.Maximum = 10;
                    cantorSettings.Visibility = Visibility.Visible;
                    distance.Value = 25;
                    break;
                default:
                    iterations.Maximum = 10;
                    treeSettings.Visibility = Visibility.Visible;
                    coef.Value = 0.6;
                    firstAngle.Value = 45;
                    secondAngle.Value = 45;
                    break;
            }
            DrawFractal();
        }

        /// <summary>
        /// Отрисовка фрактала.
        /// </summary>
        private void DrawFractal()
        {
            try
            {
                if (mainCanvas is null)
                    return;
                mainCanvas.Children.Clear();
                SolidColorBrush color1 = new(Color.FromRgb((byte)sRed.Value, (byte)sGreen.Value, (byte)sBlue.Value));
                startColorLabel.Foreground = color1;
                SolidColorBrush color2 = new(Color.FromRgb((byte)eRed.Value, (byte)eGreen.Value, (byte)eBlue.Value));
                endColorLabel.Foreground = color2;
                switch ((type.SelectedItem as ComboBoxItem)?.Name)
                {
                    case "koch":
                        new Koch(mainCanvas, (int)iterations.Value, color1, color2).DrawFractal();
                        break;
                    case "carpet":
                        new Carpet(mainCanvas, (int)iterations.Value, color1, color2).DrawFractal();
                        break;
                    case "triangle":
                        new Triangle(mainCanvas, (int)iterations.Value, color1, color2).DrawFractal();
                        break;
                    case "cantor":
                        new Cantor(mainCanvas, (int)iterations.Value, distance.Value, color1, color2).DrawFractal();
                        break;
                    default:
                        new Tree(mainCanvas, (int)iterations.Value, coef.Value, (int)firstAngle.Value, (int)secondAngle.Value, color1, color2).DrawFractal();
                        break;
                }
                ChangeCanvas();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка");
            }
        }

        /// <summary>
        /// Изменение фрактала (зум и/или перемещение).
        /// </summary>
        private void ChangeCanvas()
        {
            try
            {
                TransformGroup group = new();
                group.Children.Add(canvasTranslate);
                group.Children.Add(canvasZoom);
                mainCanvas.RenderTransform = group;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка");
            }
        }

        /// <summary>
        /// Смена количества итераций.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void IterationsChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            DrawFractal();
        }

        /// <summary>
        /// Смена начального цвета.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void StartColorChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            DrawFractal();
        }

        /// <summary>
        /// Смена конечного цвета.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void EndColorChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            DrawFractal();
        }

        /// <summary>
        /// Изменение зума.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void ZoomChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (mainCanvas is null)
                return;
            mainCanvas.Width = zoom.Value * Side;
            mainCanvas.Height = zoom.Value * Side;
            canvasZoom = new()
            {
                ScaleX = zoom.Value,
                ScaleY = zoom.Value
            };
            ChangeCanvas();
        }

        /// <summary>
        /// Изменение коэффициента дерева.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void CoefChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            DrawFractal();
        }

        /// <summary>
        /// Изменение первого угла дерева.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void FirstAngleChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            DrawFractal();
        }

        /// <summary>
        /// Изменение второго угла дерева.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void SecondAngleChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            DrawFractal();
        }

        /// <summary>
        /// Изменение дистанции множества Кантора.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void DistanceChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            DrawFractal();
        }

        /// <summary>
        /// Начало движения холста.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void StartMove(object sender, MouseButtonEventArgs e)
        {
            firstPosition = (e.GetPosition(this).X - (canvasTranslate.X * zoom.Value), e.GetPosition(this).Y - (canvasTranslate.Y * zoom.Value));
            isMoving = true;
        }

        /// <summary>
        /// Движение холста.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void Move(object sender, MouseEventArgs e)
        {
            if (isMoving)
            {
                canvasTranslate = new TranslateTransform
                {
                    X = (e.GetPosition(this).X - firstPosition.Item1) / zoom.Value,
                    Y = (e.GetPosition(this).Y - firstPosition.Item2) / zoom.Value
                };
                ChangeCanvas();
            }
        }

        /// <summary>
        /// Конец движения холста.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void MoveEnd(object sender, MouseButtonEventArgs e)
        {
            isMoving = false;
        }

        /// <summary>
        /// Прерывание движения холста (мышь вышла за приделы области видимости).
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void MoveBreak(object sender, MouseEventArgs e)
        {
            isMoving = false;
        }

        /// <summary>
        /// Сброс перемещения.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void ResetMove(object sender, RoutedEventArgs e)
        {
            canvasTranslate = new TranslateTransform();
            ChangeCanvas();
        }

        /// <summary>
        /// Сохранение видимой области.
        /// </summary>
        /// <param name="sender">Инициализатор.</param>
        /// <param name="e">Аргументы события.</param>
        private void Save(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog dialog = new()
                {
                    AddExtension = true,
                    Filter = "изображение PNG ( *.png )|*.png;",
                    FileName = $"Fractal_{DateTimeOffset.Now.ToUnixTimeMilliseconds()}"
                };
                if (dialog.ShowDialog() == true)
                {
                    string filename = dialog.FileName;
                    Rect rect = new(new Size(Side, Side));
                    RenderTargetBitmap rtb = new((int)rect.Right, (int)rect.Bottom, 96d, 96d, PixelFormats.Default);
                    rtb.Render(mainCanvas);
                    BitmapEncoder pngEncoder = new PngBitmapEncoder();
                    pngEncoder.Frames.Add(BitmapFrame.Create(rtb));

                    System.IO.MemoryStream ms = new();

                    pngEncoder.Save(ms);
                    ms.Close();
                    System.IO.File.WriteAllBytes(filename, ms.ToArray());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка! {ex.Message}", "Ошибка");
            }
        }
    }
}
