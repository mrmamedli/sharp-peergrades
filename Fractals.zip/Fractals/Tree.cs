﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Fractals
{
    /// <summary>
    /// Класс отрисовки обдуваемого ветром фрактального дерева.
    /// </summary>
    public class Tree : Fractal
    {
        /// <summary>
        /// Угол первого отрезка в радианах.
        /// </summary>
        private readonly double nextAngleLeft;

        /// <summary>
        /// Угол второго отрезка в радианах.
        /// </summary>
        private readonly double nextAngleRight;

        /// <summary>
        /// Коэффициент, определяющий отношение длин отрезков на текущей и последующей итерации.
        /// </summary>
        private readonly double coef;

        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="canvas">Холст на котором происходит отрисовка.</param>
        /// <param name="iterations">Количество итераций построения.</param>
        /// <param name="coef">Коэффициент, определяющий отношение длин отрезков на текущей и последующей итерации.</param>
        /// <param name="nextAngleLeft">Угол первого отрезка в радианах.</param>
        /// <param name="nextAngleRight">Угол второго отрезка в радианах.</param>
        /// <param name="startColor">Начальный цвет отрисовки.</param>
        /// <param name="endColor">Конечный цвет отрисовки.</param>
        public Tree(Canvas canvas, int iterations, double coef, int nextAngleLeft, int nextAngleRight, SolidColorBrush startColor, SolidColorBrush endColor) : base(canvas, iterations, startColor, endColor)
        {
            this.nextAngleLeft = nextAngleLeft * Math.PI / 180;
            this.nextAngleRight = nextAngleRight * Math.PI / 180;
            this.coef = coef;
        }

        /// <summary>
        /// Построение фрактала.
        /// </summary>
        public override void DrawFractal()
        {
            DrawTree(Side / 2, Side * 0.8, 0, 90 * Math.PI / 180, Side * 0.2);
        }

        /// <summary>
        /// Метод отрисовки итерации.
        /// </summary>
        /// <param name="x">Абсцисса точки, из которой выходят отрезки.</param>
        /// <param name="y">Ордината точки, из которой выходят отрезки.</param>
        /// <param name="iteration">Номер итерации построения.</param>
        /// <param name="angle">Угол, под которым изображен отрезок предыдущей итерации.</param>
        /// <param name="lineLength">Длина отрезка.</param>
        private void DrawTree(double x, double y, int iteration, double angle, double lineLength)
        {
            if (iteration == Iterations)
            {
                return;
            }

            var newX = x - (Math.Cos(angle) * lineLength);
            var newY = y - (Math.Sin(angle) * lineLength);

            DrawLine(Colors[iteration], 2, (x, y), (newX, newY));

            DrawTree(newX, newY, iteration + 1, angle - nextAngleLeft, lineLength * coef);
            DrawTree(newX, newY, iteration + 1, angle + nextAngleRight, lineLength * coef);
        }
    }
}
