﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Fractals
{
    /// <summary>
    /// Класс отрисовки треугольника Серпинского.
    /// </summary>
    public class Triangle : Fractal
    {
        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="canvas">Холст на котором происходит отрисовка.</param>
        /// <param name="iterations">Количество итераций построения.</param>
        /// <param name="startColor">Начальный цвет отрисовки.</param>
        /// <param name="endColor">Конечный цвет отрисовки.</param>
        public Triangle(Canvas canvas, int iterations, SolidColorBrush startColor, SolidColorBrush endColor) : base(canvas, iterations, startColor, endColor)
        {
        }

        /// <summary>
        /// Построение фрактала.
        /// </summary>
        public override void DrawFractal()
        {
            (double, double) point1 = ((Side / 2) - (3 * Side * 0.3 / 2), Side * 0.9);
            (double, double) point2 = ((Side / 2) + (3 * Side * 0.3 / 2), Side * 0.9);
            (double, double) point3 = (Side / 2, Side - 30 - (3 * Side * 0.3 * Math.Sin(Math.PI / 3)));
            DrawLine(Colors[0], 2, point1, point2);
            DrawLine(Colors[0], 2, point2, point3);
            DrawLine(Colors[0], 2, point1, point3);
            DrawTriangle(point1, point2, point3, 1);
        }

        /// <summary>
        /// Метод отрисовки итерации.
        /// </summary>
        /// <param name="point1">Первая вершина треугольника.</param>
        /// <param name="point2">Вторая вершина треугольника.</param>
        /// <param name="point3">Третья вершина треугольника.</param>
        /// <param name="iteration">Номер итерации построения.</param>
        private void DrawTriangle((double, double) point1, (double, double) point2, (double, double) point3, int iteration)
        {
            if (iteration == Iterations)
            {
                return;
            }

            var point12 = ((point1.Item1 + point2.Item1) / 2, (point1.Item2 + point2.Item2) / 2);
            var point23 = ((point2.Item1 + point3.Item1) / 2, (point2.Item2 + point3.Item2) / 2);
            var point13 = ((point1.Item1 + point3.Item1) / 2, (point1.Item2 + point3.Item2) / 2);

            DrawLine(Colors[iteration], 2, point12, point23);
            DrawLine(Colors[iteration], 2, point23, point13);
            DrawLine(Colors[iteration], 2, point12, point13);

            DrawTriangle(point1, point12, point13, iteration + 1);
            DrawTriangle(point2, point12, point23, iteration + 1);
            DrawTriangle(point3, point23, point13, iteration + 1);
        }
    }
}
