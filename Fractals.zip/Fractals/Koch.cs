﻿using System;
using System.Windows.Controls;
using System.Windows.Media;

namespace Fractals
{
    /// <summary>
    /// Класс отрисовки кривой Коха.
    /// </summary>
    public class Koch : Fractal
    {
        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="canvas">Холст на котором происходит отрисовка.</param>
        /// <param name="iterations">Количество итераций построения.</param>
        /// <param name="startColor">Начальный цвет отрисовки.</param>
        /// <param name="endColor">Конечный цвет отрисовки.</param>
        public Koch(Canvas canvas, int iterations, SolidColorBrush startColor, SolidColorBrush endColor) : base(canvas, iterations, startColor, endColor)
        {
        }

        /// <summary>
        /// Построение фрактала.
        /// </summary>
        public override void DrawFractal()
        {
            var point1 = ((Side / 2) - (3 * Side * 0.3 / 2), Side - 30);
            var point2 = ((Side / 2) + (3 * Side * 0.3 / 2), Side - 30);
            DrawLine(Colors[0], 2, point1, point2);
            DrawKoch(point1, point2, (Side / 2, Side - 30 + (3 * Side * 0.3 * Math.Sin(Math.PI / 3))), 1);
        }

        /// <summary>
        /// Метод отрисовки итерации (по мотивам метода Марии Константиновны).
        /// </summary>
        /// <param name="point1">Первая точка построения текущей итерации (граница отрезка).</param>
        /// <param name="point2">Вторая точка построения текущей итерации (граница отрезка).</param>
        /// <param name="point3">Третья точка построения текущей итерации (мнимая).</param>
        /// <param name="iteration">Номер итерации построения.</param>
        private void DrawKoch((double, double) point1, (double, double) point2, (double, double) point3, int iteration)
        {
            if (iteration == Iterations)
            {
                return;
            }

            var point4 = ((point2.Item1 + 2 * point1.Item1) / 3, (point2.Item2 + (2 * point1.Item2)) / 3);
            var point5 = (((2 * point2.Item1) + point1.Item1) / 3, (point1.Item2 + (2 * point2.Item2)) / 3);
            var pointS = ((point2.Item1 + point1.Item1) / 2, (point2.Item2 + point1.Item2) / 2);
            var pointN = (((4 * pointS.Item1) - point3.Item1) / 3, ((4 * pointS.Item2) - point3.Item2) / 3);
            
            DrawLine(Colors[iteration], 2, point4, pointN);
            DrawLine(Colors[iteration], 2, point5, pointN);
            DrawLine(Brushes.White, 3, point4, point5);

            DrawKoch(point4, pointN, point5, iteration + 1);
            DrawKoch(pointN, point5, point4, iteration + 1);
            DrawKoch(point1, point4, (((2 * point1.Item1) + point3.Item1) / 3, ((2 * point1.Item2) + point3.Item2) / 3), iteration + 1);
            DrawKoch(point5, point2, (((2 * point2.Item1) + point3.Item1) / 3, ((2 * point2.Item2) + point3.Item2) / 3), iteration + 1);
        }
    }
}
