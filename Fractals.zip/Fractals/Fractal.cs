﻿using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Fractals
{
    /// <summary>
    /// Базовый класс - основа для классов отрисовки фракталов.
    /// </summary>
    public abstract class Fractal
    {
        /// <summary>
        /// Холст на котором происходит отрисовка.
        /// </summary>
        protected readonly Canvas FractalCanvas;
        
        /// <summary>
        /// Количество итераций построения.
        /// </summary>
        protected readonly int Iterations;

        /// <summary>
        /// Массив цветов для градиента.
        /// </summary>
        protected List<SolidColorBrush> Colors;

        /// <summary>
        /// Размер холста (константа).
        /// </summary>
        protected const double Side = 1000;

        /// <summary>
        /// Базовый конструктор.
        /// </summary>
        /// <param name="canvas">Холст на котором происходит отрисовка.</param>
        /// <param name="iterations">Количество итераций построения.</param>
        /// <param name="startColor">Начальный цвет отрисовки.</param>
        /// <param name="endColor">Конечный цвет отрисовки.</param>
        protected Fractal(Canvas canvas, int iterations, SolidColorBrush startColor, SolidColorBrush endColor)
        {
            FractalCanvas = canvas;
            Iterations = iterations;
            Colors = MakeGradient(endColor, startColor, iterations);
        }

        /// <summary>
        /// Заготовка метода построения фрактала.
        /// </summary>
        public abstract void DrawFractal();

        /// <summary>
        /// Метод построения отрезка.
        /// </summary>
        /// <param name="color">Цвет отрезка.</param>
        /// <param name="size">Толщина отрезка.</param>
        /// <param name="firstPoint">Первая точка-граница отрезка.</param>
        /// <param name="secondPoint">Вторая точка-граница отрезка.</param>
        protected void DrawLine(SolidColorBrush color, int size, (double, double) firstPoint, (double, double) secondPoint)
        {
            Line line = new()
            {
                Stroke = color,
                StrokeThickness = size,
                X1 = firstPoint.Item1,
                Y1 = firstPoint.Item2,
                X2 = secondPoint.Item1,
                Y2 = secondPoint.Item2
            };
            FractalCanvas.Children.Add(line);
        }

        /// <summary>
        /// Метод для создания градиента (подробнее по ссылке из задания).
        /// </summary>
        /// <param name="startColor">Начальный цвет отрисовки.</param>
        /// <param name="endColor">Конечный цвет отрисовки.</param>
        /// <param name="size">Количество элементов в результирующем массиве.</param>
        /// <returns>Массив цветов градиента.</returns>
        private List<SolidColorBrush> MakeGradient(SolidColorBrush startColor, SolidColorBrush endColor, int size)
        {
            int rMax = startColor.Color.R;
            int rMin = endColor.Color.R;
            int gMax = startColor.Color.G;
            int gMin = endColor.Color.G;
            int bMax = startColor.Color.B;
            int bMin = endColor.Color.B;
            List<SolidColorBrush> colorList = new();
            for (var i = 0; i < size; i++)
            {
                var rAverage = rMin + (rMax - rMin) * i / size;
                var gAverage = gMin + (gMax - gMin) * i / size;
                var bAverage = bMin + (bMax - bMin) * i / size;
                colorList.Add(new SolidColorBrush(Color.FromRgb((byte)rAverage, (byte)gAverage, (byte)bAverage)));
            }
            return colorList;
        }
    }
}
