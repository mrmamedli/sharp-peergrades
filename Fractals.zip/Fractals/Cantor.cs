﻿using System.Windows.Controls;
using System.Windows.Media;

namespace Fractals
{
    /// <summary>
    /// Класс отрисовки множества Кантора.
    /// </summary>
    public class Cantor : Fractal
    {
        /// <summary>
        /// Расстояние между отрезками соседних итераций.
        /// </summary>
        private readonly double dist;

        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="canvas">Холст на котором происходит отрисовка.</param>
        /// <param name="iterations">Количество итераций построения.</param>
        /// <param name="distance">Расстояние между отрезками соседних итераций.</param>
        /// <param name="startColor">Начальный цвет отрисовки.</param>
        /// <param name="endColor">Конечный цвет отрисовки.</param>
        public Cantor(Canvas canvas, int iterations, double distance, SolidColorBrush startColor, SolidColorBrush endColor) : base(canvas, iterations, startColor, endColor)
        {
            dist = distance;
        }

        /// <summary>
        /// Построение фрактала.
        /// </summary>
        public override void DrawFractal()
        {
            var point1 = (Side / 2) - (3 * 0.3 * Side / 2);
            var point2 = (Side / 2) + (3 * 0.3 * Side / 2);
            DrawLine(Colors[0], 10, (point1, 30), (point2, 30));
            DrawCantor(point1, point2, 30 + dist, 0);
        }

        /// <summary>
        /// Метод отрисовки итерации.
        /// </summary>
        /// <param name="point1">Первая точка - граница отрезка.</param>
        /// <param name="point2">Вторая точка - граница отрезка.</param>
        /// <param name="distance">Расстояние от отрезка до верхней границы.</param>
        /// <param name="iteration">Номер итерации построения.</param>
        private void DrawCantor(double point1, double point2, double distance, int iteration)
        {
            if (iteration == Iterations)
            {
                return;
            }

            var point3 = ((point1 * 2) + point2) / 3;
            var point4 = (point1 + (2 * point2)) / 3;

            DrawLine(Colors[iteration], 10, (point1, distance), (point3, distance));
            DrawLine(Colors[iteration], 10, (point4, distance), (point2, distance));

            DrawCantor(point1, point3, dist + distance, iteration + 1);
            DrawCantor(point4, point2, dist + distance, iteration + 1);
        }
    }
}
