﻿using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Fractals
{
    /// <summary>
    /// Класс отрисовки ковра Серпинского.
    /// </summary>
    public class Carpet : Fractal
    {
        /// <summary>
        /// Конструктор класса.
        /// </summary>
        /// <param name="canvas">Холст на котором происходит отрисовка.</param>
        /// <param name="iterations">Количество итераций построения.</param>
        /// <param name="startColor">Начальный цвет отрисовки.</param>
        /// <param name="endColor">Конечный цвет отрисовки.</param>
        public Carpet(Canvas canvas, int iterations, SolidColorBrush startColor, SolidColorBrush endColor) : base(canvas, iterations, startColor, endColor)
        {
        }

        /// <summary>
        /// Построение фрактала.
        /// </summary>
        public override void DrawFractal()
        {
            Rectangle rectangle = new()
            {
                Width = Side,
                Height = Side,
                Fill = Brushes.LightGray
            };
            FractalCanvas.Children.Add(rectangle);

            DrawCarpet((0, 0), Side, 1);
        }

        /// <summary>
        /// Метод отрисовки итерации.
        /// </summary>
        /// <param name="point">Верхняя левая точка квадрата текущей итерации.</param>
        /// <param name="length">Длина стороны квадрата.</param>
        /// <param name="iteration">Номер итерации построения.</param>
        private void DrawCarpet((double, double) point, double length, int iteration)
        {
            if (iteration == Iterations)
            {
                return;
            }

            Rectangle rectangle = new()
            {
                Width = length / 3,
                Height = length / 3,
                Fill = Colors[iteration]
            };
            Canvas.SetTop(rectangle, point.Item2 + (length / 3));
            Canvas.SetLeft(rectangle, point.Item1 + (length / 3));
            FractalCanvas.Children.Add(rectangle);

            DrawCarpet(point, length / 3, iteration + 1);
            DrawCarpet((point.Item1 + (length / 3), point.Item2), length / 3, iteration + 1);
            DrawCarpet((point.Item1 + (2 * length / 3), point.Item2), length / 3, iteration + 1);
            DrawCarpet((point.Item1, point.Item2 + (length / 3)), length / 3, iteration + 1);
            DrawCarpet((point.Item1, point.Item2 + (2 * length / 3)), length / 3, iteration + 1);
            DrawCarpet((point.Item1 + (length / 3), point.Item2 + (2 * length / 3)), length / 3, iteration + 1);
            DrawCarpet((point.Item1 + (2 * length / 3), point.Item2 + (length / 3)), length / 3, iteration + 1);
            DrawCarpet((point.Item1 + (2 * length / 3), point.Item2 + (2 * length / 3)), length / 3, iteration + 1);
        }
    }
}
